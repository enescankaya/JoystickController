﻿using JoystickController.Joystick_Controllers;
using JoystickController.Kumanda_Kontrolculeri;
using SharpDX.DirectInput;
using SharpDX.XInput;
using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
namespace JoystickController.Interfaces
{
    public static class CommonMethods
    {
        /// <summary>
        ///             XBOX_KUMANDA ,       EXTREME_KUMANDA ,      DEFAULT
        /// </summary>
        public enum KUMANDA_TIPI
        {
            XBOX_KUMANDA,
            EXTREME_KUMANDA,
            DEFAULT
        }
        /// <summary>
        ///         GimbalMode,        IhaMode,        AllMode ,NoMode
        /// </summary>
        public enum FunctionMode
        {
            GimbalMode,
            IhaMode,
            AllMode,
            NoMode
        }
        /// <summary>
        /// Verilen Modun İndex Numarasını Dööndürü.
        /// </summary>
        /// <param name="mode"></param>
        /// <returns></returns>
        public static int GetModeIndex(FunctionMode mode)
        {
            if (mode is FunctionMode.GimbalMode) { return 0; }
            if (mode is FunctionMode.IhaMode) { return 1; }
            if (mode is FunctionMode.AllMode) { return 2; }
            else { return 3; }
        }
        /// <summary>
        /// Verilen index'in Fonksiyon Modunun Döndürür(comboboxlar için)
        /// </summary>
        /// <param name="index">mode index</param>
        /// <returns>Mode of İndex</returns>
        public static FunctionMode getMode(int index)
        {
            if (index == 0) { return FunctionMode.GimbalMode; }
            if (index == 1) { return FunctionMode.IhaMode; }
            if (index == 2) { return FunctionMode.AllMode; }
            else { return FunctionMode.NoMode; }
        }

        #region PARAMETERS
        /// <summary>
        /// XBox İçin Kontrolcü
        /// </summary>
        public static Controller? controller;
        /// <summary>
        /// Extreme İçin Kontrolcü
        /// </summary>
        public static DirectInput directInput;
        public static Joystick? extremeJoystick;
        public static int SettingsTabIndex = 0;
        public static int GimbalTabIndex = 1;
        public static int IhaTabIndex = 2;
        public static int AllTabIndex = 3;
        public static int ProgressBarFullValue = 1;
        public const int NumberOfButton_Extreme = 12;
        public const int NumberOfButton_XBox = 14;
        public static bool VibrationON = true;
        public static bool VibrationOFF = false;
        public static int NumberOfEmplyTextBox = 0;
        //public static int GimbalMode = 0;
        //public static int IhaMode = 1;
        //public static int AllMode = 2;
        //public static int NoMode = -1;
        #endregion
        /// <summary>
        /// Hangi Controllerin Bağlı Olduğunu Kontrol Eden Fonksiyon.
        /// KUMANDA _TIPI Enum tipi döndürür.
        /// </summary>
        /// <returns></returns>
        public static KUMANDA_TIPI WhichJoystick(Controller controller, Joystick extremeJoystick)
        {
            if (controller != null && controller.IsConnected)
            {
                return CommonMethods.KUMANDA_TIPI.XBOX_KUMANDA;
            }
            else if (extremeJoystick != null)
            {
                return CommonMethods.KUMANDA_TIPI.EXTREME_KUMANDA;
            }
            return CommonMethods.KUMANDA_TIPI.DEFAULT;

        }
        public static void AddButtonsForFunctions(controlXBox cXBox, controlExtreme cExtreme, Controller controller, Joystick extremeJoystick)
        {
            if (CommonMethods.KUMANDA_TIPI.XBOX_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick))
            {

                cXBox.FunctionList.Add(new ButtonState());
                cXBox.FunctionList.Add(new ButtonState());
                cXBox.FunctionList.Add(new ButtonState());
                cXBox.FunctionList.Add(new ButtonState());
                cXBox.FunctionList.Add(new ButtonState());
                cXBox.FunctionList.Add(new ButtonState());
                cXBox.FunctionList.Add(new ButtonState());
                cXBox.FunctionList.Add(new ButtonState());
                cXBox.FunctionList.Add(new ButtonState());
                cXBox.FunctionList.Add(new ButtonState());
                cXBox.FunctionList.Add(new ButtonState());
                cXBox.FunctionList.Add(new ButtonState());
                cXBox.FunctionList.Add(new ButtonState());
                cXBox.FunctionList.Add(new ButtonState());
            }
            if (CommonMethods.KUMANDA_TIPI.EXTREME_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick))
            {

                cExtreme.FunctionList.Add(new ButtonState());
                cExtreme.FunctionList.Add(new ButtonState());
                cExtreme.FunctionList.Add(new ButtonState());
                cExtreme.FunctionList.Add(new ButtonState());
                cExtreme.FunctionList.Add(new ButtonState());
                cExtreme.FunctionList.Add(new ButtonState());
                cExtreme.FunctionList.Add(new ButtonState());
                cExtreme.FunctionList.Add(new ButtonState());
                cExtreme.FunctionList.Add(new ButtonState());
                cExtreme.FunctionList.Add(new ButtonState());
                cExtreme.FunctionList.Add(new ButtonState());
                cExtreme.FunctionList.Add(new ButtonState());
            }
        }
        /// <summary>
        /// SaveSettings() den ALdığı filePath'ine XBox Kontrolcu Ayarını Class OLarak kaydeder.
        /// </summary>
        /// <param name="filePath"> SaveSettings() den Gönderilen Dosya Yolu</param>
        public static void SaveToFileXBox(string filePath, controlXBox XBoxControllerClass)
        {
            try
            {
                var options = new JsonSerializerOptions
                {
                    WriteIndented = true // JSON'u daha okunabilir hale getirir
                };

                string jsonString = JsonSerializer.Serialize(XBoxControllerClass, options);
                File.WriteAllText(filePath, jsonString);
                File.SetAttributes(filePath, FileAttributes.ReadOnly);
            }
            catch (Exception msg)
            {
                MessageBox.Show(msg.Message);
            }
        }
        /// <summary>
        /// SaveSettings() den ALdığı filePath'ine  Extreme Kontrolcu Ayarını Class OLarak kaydeder.
        /// </summary>
        /// <param name="filePath">SaveSettings() den Gönderilen Dosya Yolu</param>
        public static void SaveToFileEx(string filePath, controlExtreme ExtremeControllerClass)
        {
            try
            {
                var options = new JsonSerializerOptions
                {
                    WriteIndented = true // JSON'u daha okunabilir hale getirir
                };

                string jsonString = JsonSerializer.Serialize(ExtremeControllerClass, options);
                File.WriteAllText(filePath, jsonString);
            }
            catch (Exception msg)
            {
                MessageBox.Show(msg.Message);
            }
        }
        /// <summary>
        /// Alınan min,trim ve max texbox içindeki int verilerini birbiriyle olan büyüklük karşılaştırmasını yapan method.
        /// </summary>
        /// <param name="minTextBox"></param>
        /// <param name="trimTextBox"></param>
        /// <param name="maxTextBox"></param>
        public static bool ValidateMinTrimMax(TextBox minTextBox, TextBox? trimTextBox, TextBox maxTextBox, TextBox CurrentTextBox)
        {
            bool value = false;
            if (minTextBox != null && trimTextBox != null && maxTextBox != null)
            {
                if (int.TryParse(minTextBox.Text, out int min) &&
                    int.TryParse(trimTextBox.Text, out int trim) &&
                    int.TryParse(maxTextBox.Text, out int max))
                {
                    if (trim < min)
                    {
                        MessageBox.Show("Trim değeri min değerinden büyük olmalıdır.", "Hata", MessageBoxButton.OK, MessageBoxImage.Error);
                        CurrentTextBox.Text = CurrentTextBox.Tag.ToString();
                        value = true;
                    }
                    else if (trim > max)
                    {
                        MessageBox.Show("Trim değeri max değerinden küçük olmalıdır.", "Hata", MessageBoxButton.OK, MessageBoxImage.Error);
                        CurrentTextBox.Text = CurrentTextBox.Tag.ToString();
                        value = true;
                    }
                    else
                    {
                        value = false;
                    }
                }
            }
            else if (trimTextBox == null)
            {
                if (int.TryParse(minTextBox.Text, out int min) &&
                    int.TryParse(maxTextBox.Text, out int max))
                {
                    if (max < min)
                    {
                        MessageBox.Show("max değeri min değerinden büyük olmalıdır.", "Hata", MessageBoxButton.OK, MessageBoxImage.Error);
                        CurrentTextBox.Text = CurrentTextBox.Tag.ToString();
                        value = true;
                    }
                    else
                    {
                        value = false;
                    }

                }
            }
            return value;
        }
        /// <summary>
        /// Set ve Apply Changes Butonları İle Çalıştırılır
        /// Page'deki TextBoxları Gezip, Bunların Textlerinin Doğru Formatta Olup Olmadıkllarını,İlgili Textoxlarla Kıyaslamalarının (min,trim,max) Yapıldığı Method.
        /// </summary>
        /// <param name="parent"></param>
        public static void CheckAllTextBoxes(DependencyObject parent, controlExtreme ExtremeControllerClass, controlXBox XBoxControllerClass, Controller controller, Joystick extremeJoystick)
        {
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);
                if (child is TextBox textBox && (!textBox.Name.Contains("xStepSize") && !textBox.Name.Contains("yStepSize") && !textBox.Name.Contains("pilotName") && !textBox.Name.Contains("trim7")))
                {
                    bool isEmpty = (string.IsNullOrWhiteSpace(textBox.Text));
                    if (isEmpty)
                    {
                        NumberOfEmplyTextBox++;
                        textBox.Background = new SolidColorBrush(Colors.IndianRed);
                    }
                    else
                    {
                        if (true == uint.TryParse(textBox.Text, out uint deger_u32))
                        {
                            textBox.Background = new SolidColorBrush(Colors.White);
                            switch (textBox.Name.ToString())
                            {
                                case "min1":
                                    {
                                        if (CommonMethods.KUMANDA_TIPI.EXTREME_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick))
                                        {
                                            ExtremeControllerClass.MinX = deger_u32;
                                        }
                                        else
                                        {
                                            XBoxControllerClass.MinLeftThumbstickX = deger_u32;
                                        }
                                        break;
                                    }
                                case "trim1":
                                    {
                                        if (CommonMethods.KUMANDA_TIPI.EXTREME_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick))
                                        {
                                            ExtremeControllerClass.TrimValueX = deger_u32;
                                        }
                                        else
                                        {
                                            XBoxControllerClass.TrimLeftThumbstickX = deger_u32;
                                        }
                                        break;
                                    }
                                case "max1":
                                    if (CommonMethods.KUMANDA_TIPI.EXTREME_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick)) ExtremeControllerClass.MaxX = deger_u32;
                                    else XBoxControllerClass.MaxLeftThumbstickX = deger_u32;
                                    break;
                                case "min2":
                                    if (CommonMethods.KUMANDA_TIPI.EXTREME_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick)) ExtremeControllerClass.MinY = deger_u32;
                                    else XBoxControllerClass.MinLeftThumbstickY = deger_u32;
                                    break;
                                case "trim2":
                                    if (CommonMethods.KUMANDA_TIPI.EXTREME_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick)) ExtremeControllerClass.TrimValueY = deger_u32;
                                    else XBoxControllerClass.TrimLeftThumbstickY = deger_u32;
                                    break;
                                case "max2":
                                    if (CommonMethods.KUMANDA_TIPI.EXTREME_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick)) ExtremeControllerClass.MaxY = deger_u32;
                                    else XBoxControllerClass.MaxLeftThumbstickY = deger_u32;
                                    break;
                                case "min3":
                                    if (CommonMethods.KUMANDA_TIPI.EXTREME_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick)) ExtremeControllerClass.MinZ = deger_u32;
                                    else XBoxControllerClass.MinRightThumbstickX = deger_u32;
                                    break;
                                case "trim3":
                                    if (CommonMethods.KUMANDA_TIPI.EXTREME_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick)) ExtremeControllerClass.TrimValueZ = deger_u32;
                                    else XBoxControllerClass.TrimRightThumbstickX = deger_u32;
                                    break;
                                case "max3":
                                    if (CommonMethods.KUMANDA_TIPI.EXTREME_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick)) ExtremeControllerClass.MaxZ = deger_u32;
                                    else XBoxControllerClass.MaxRightThumbstickX = deger_u32;
                                    break;
                                case "min4":
                                    if (CommonMethods.KUMANDA_TIPI.EXTREME_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick)) { ExtremeControllerClass.MinHat = deger_u32; ExtremeControllerClass.XValueHat = deger_u32; ExtremeControllerClass.YValueHat = deger_u32; }
                                    else XBoxControllerClass.MinRightThumbstickY = deger_u32;
                                    break;
                                case "trim4":
                                    if (CommonMethods.KUMANDA_TIPI.EXTREME_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick)) ExtremeControllerClass.TrimValueHat = deger_u32;
                                    else XBoxControllerClass.TrimRightThumbstickY = deger_u32;
                                    break;
                                case "max4":
                                    if (CommonMethods.KUMANDA_TIPI.EXTREME_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick)) ExtremeControllerClass.MaxHat = deger_u32;
                                    else XBoxControllerClass.MaxRightThumbstickY = deger_u32;
                                    break;
                                case "min5":
                                    if (CommonMethods.KUMANDA_TIPI.EXTREME_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick)) ExtremeControllerClass.MinThrottle = deger_u32;
                                    else XBoxControllerClass.MinLeftTrigger = deger_u32;
                                    break;
                                case "max5":
                                    if (CommonMethods.KUMANDA_TIPI.EXTREME_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick)) ExtremeControllerClass.MaxThrottle = deger_u32;
                                    else XBoxControllerClass.MaxLeftTrigger = deger_u32;
                                    break;
                                case "min6":
                                    if (CommonMethods.KUMANDA_TIPI.EXTREME_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick)) ExtremeControllerClass.MaxThrottle = deger_u32;
                                    else XBoxControllerClass.MinRightTrigger = deger_u32;
                                    break;
                                case "max6":
                                    if (CommonMethods.KUMANDA_TIPI.EXTREME_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick)) ExtremeControllerClass.MaxThrottle = deger_u32;
                                    else XBoxControllerClass.MaxRightTrigger = deger_u32;
                                    break;
                                case "min7":
                                    if (CommonMethods.KUMANDA_TIPI.XBOX_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick))
                                    {
                                        XBoxControllerClass.DPadMin = deger_u32;
                                        textBox.Text = XBoxControllerClass.DPadMin.ToString();
                                        XBoxControllerClass.DPadY = deger_u32;
                                        XBoxControllerClass.DPadX = deger_u32;
                                    }
                                    break;
                                case "max7":
                                    if (CommonMethods.KUMANDA_TIPI.XBOX_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick))
                                    {
                                        XBoxControllerClass.DPadMax = deger_u32;
                                        textBox.Text = XBoxControllerClass.DPadMax.ToString();
                                    }
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                }
                else
                {
                    CheckAllTextBoxes(child, ExtremeControllerClass, XBoxControllerClass, controller, extremeJoystick);

                }
            }
        }
    }
}
