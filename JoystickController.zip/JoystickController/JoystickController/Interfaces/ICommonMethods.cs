﻿using SharpDX.DirectInput;
using SharpDX.XInput;

namespace JoystickController.Interfaces
{
    public partial interface ICommonMethods
    {
        /// <summary>
        ///             XBOX_KUMANDA ,       EXTREME_KUMANDA ,      DEFAULT
        /// </summary>
        public enum FunctionModes
        {
            GimbalMode = 0,
            IhaMode = 1,
            AllMode = 2,
            NoMode = 3
        }
        public enum KUMANDA_TIPI
        {
            XBOX_KUMANDA,
            EXTREME_KUMANDA,
            DEFAULT
        }
        /// <summary>
        /// Hangi Controllerin Bağlı Olduğunu Kontrol Eden Fonksiyon.
        /// KUMANDA _TIPI Enum tipi döndürür.
        /// </summary>
        /// <returns></returns>
        public static KUMANDA_TIPI WhichJoystick(Controller controller, Joystick extremeJoystick)
        {

            if (controller != null && controller.IsConnected)
            {
                return KUMANDA_TIPI.XBOX_KUMANDA;
            }
            else if (extremeJoystick != null)
            {
                return KUMANDA_TIPI.EXTREME_KUMANDA;
            }
            return KUMANDA_TIPI.DEFAULT;
        }
    }
}
