﻿namespace JoystickController.Binding_Classes
{
    public class InputState
    {
        public string Input { get; set; }
        public string NewValue { get; set; }
        public string Min { get; set; }
        public string Max { get; set; }
    }
}
