﻿using System.Windows.Controls;

namespace JoystickController.User_Controllers
{
    /// <summary>
    /// FunctionRowController.xaml etkileşim mantığı
    /// </summary>
    public partial class FunctionRowController : UserControl
    {
        public FunctionRowController()
        {
            InitializeComponent();
        }
    }
}
