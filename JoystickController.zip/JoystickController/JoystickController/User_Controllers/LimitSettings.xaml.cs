﻿using JoystickController.Interfaces;
using Microsoft.Win32;
using SharpDX.DirectInput;
using SharpDX.XInput;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
namespace JoystickController.User_Controllers
{
    /// <summary>
    /// LimitSettings.xaml etkileşim mantığı
    /// </summary>
    public partial class LimitSettings : UserControl
    {
        #region Atamalar
        private Controller controller;
        private DirectInput directInput;
        private Joystick extremeJoystick;
        JoystickValuesPage JoystickValuesPage;
        private int tempTextBox;
        #endregion
        /// <summary>
        /// XBox Controller İçin Controller index ayarlaması yapar, Kullanılan JoystickValuesPage Referansını Gönderir.
        /// Referans Değerini MainPage deki Mevcut Classlara Ulaşabilmek İçin Kullanıyoruz.
        /// </summary>
        /// <param name="index">XBox Controller İçin Kullanılan Controller İndexi</param>
        /// <param name="jvp">JoystickValuesPage</param>
        public void setControllerForXbox(int index, JoystickValuesPage jvp)
        {
            controller = new Controller((UserIndex)index);
            this.JoystickValuesPage = jvp;
            Set_Labels_For_XBox_Controller();
        }
        /// <summary>
        /// Extreme Controller İçin Controller ayarlaması yapar, Kullanılan JoystickValuesPage Referansını Gönderir.
        /// Referans Değerini MainPage deki Mevcut Classlara Ulaşabilmek İçin Kullanıyoruz.
        /// </summary>
        /// <param name="joystick">Extreme Controller İçin Kullanılan Controller Referansı</param>
        /// <param name="jvp">JoystickValuesPage</param>
        public void setControllerForExtreme(Joystick joystick, JoystickValuesPage jvp)
        {
            extremeJoystick = joystick;
            Set_TexBoxes_For_Extreme_Controller();
            this.JoystickValuesPage = jvp;
            Set_Labels_For_Extreme_Controller();
        }
        public LimitSettings()
        {
            InitializeComponent();
        }
        /// <summary>
        /// XBox Kontrolcü Seçildiğinde Değişmesi Gereken Öğeleri Ayarlayan Fonksiyon
        /// </summary>
        public void Set_Labels_For_XBox_Controller()
        {
            v1.Text = "Left Thumbstick X";
            v2.Text = "Left Thumbstick Y";
            v3.Text = "Right Thumbstick X";
            v4.Text = "Right Thumbstick Y";
            v5.Text = "Left Trigger";
            v6.Text = "Right Trigger";
            PilotNameSection.Visibility = Visibility.Hidden;
            XstepSizeValuesLabel.Content = $"X Axis Step Size: {JoystickValuesPage.XBoxControllerClass.XStepSize}";
            YstepSizeValuesLabel.Content = $"Y Axis Step Size: {JoystickValuesPage.XBoxControllerClass.YStepSize}";
            StepSizeGroup.Header = "DPad Step Size Settings";
        }
        /// <summary>
        /// Extreme Kontrolcü Seçildiğinde Değişmesi Gereken Öğeleri Ayarlayan Fonksiyon
        /// </summary>
        public void Set_Labels_For_Extreme_Controller()
        {
            v1.Text = "X Axis";
            v2.Text = "Y Axis";
            v3.Text = "Z Axis";
            v4.Text = "HAT SWITCH";
            v5.Text = "THROTTLE";
            StepSizeGroup.Header = "Hat Switch Step Size Settings";
            PilotNameSection.Visibility = Visibility.Hidden;
            lastGroupBox.Visibility = Visibility.Collapsed;
            trim5.Text = 23.ToString();//Bos hata degeri donmesin diye
            trim4.Text = 23.ToString();//Bos hata degeri donmesin diye
            XstepSizeValuesLabel.Content = $"X Axis Step Size: {JoystickValuesPage.ExtremeControllerClass.XHatStepSize}";
            YstepSizeValuesLabel.Content = $"Y Axis Step Size: {JoystickValuesPage.ExtremeControllerClass.YHatStepSize}";
        }
        /// <summary>
        /// Extreme Kontrolcü Seçildiğinde Gizlenmesi Gereken Öğeleri Ayarlayan Fonksiyon
        /// </summary>
        public void Set_TexBoxes_For_Extreme_Controller()
        {
            min6.IsEnabled = false;
            min6.Visibility = Visibility.Collapsed;
            max6.Visibility = Visibility.Collapsed;
            cb6.Visibility = Visibility.Collapsed;
            trim4.Visibility = Visibility.Hidden;
            DPadLimitsGroup.Visibility = Visibility.Collapsed;

        }
        /// <summary>
        /// Her Metin Değiştiğinde MİN,TRİM,MAX karşılaştırması yapan method.
        /// </summary>
        public bool textChangedSettings(TextBox textbox)
        {
            if (CommonMethods.KUMANDA_TIPI.EXTREME_KUMANDA == CommonMethods.WhichJoystick(null, extremeJoystick))
            {
                if (!(int.Parse(textbox.Text) < 65500))
                {
                    textbox.Text = textbox.Tag.ToString();
                    return false;
                }
                return
            CommonMethods.ValidateMinTrimMax(min1, trim1, max1, textbox) ||
            CommonMethods.ValidateMinTrimMax(min2, trim2, max2, textbox) ||
            CommonMethods.ValidateMinTrimMax(min3, trim3, max3, textbox) ||
            CommonMethods.ValidateMinTrimMax(min4, null, max4, textbox) ||
            CommonMethods.ValidateMinTrimMax(min5, null, max5, textbox);

            }
            if (!(int.Parse(textbox.Text) < 32500))
            {
                textbox.Text = textbox.Tag.ToString();
                return false;
            }
            return
            CommonMethods.ValidateMinTrimMax(min1, trim1, max1, textbox) ||
            CommonMethods.ValidateMinTrimMax(min2, trim2, max2, textbox) ||
            CommonMethods.ValidateMinTrimMax(min3, trim3, max3, textbox) ||
            CommonMethods.ValidateMinTrimMax(min4, trim4, max4, textbox) ||
            CommonMethods.ValidateMinTrimMax(min5, null, max5, textbox) ||
            CommonMethods.ValidateMinTrimMax(min6, null, max6, textbox) ||
            CommonMethods.ValidateMinTrimMax(min7, null, max7, textbox);
        }
        /// <summary>
        /// Reverse Seçeneğinini Aktifleştiren Ya da Kapatan CheckBox Event
        /// </summary>
        public void ReverseCheckBoxesClicks(object sender, RoutedEventArgs e)
        {
            CheckBox cb = (CheckBox)sender;
            if (CommonMethods.KUMANDA_TIPI.XBOX_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick))
            {//xbox
                if (cb == cb1)
                {
                    JoystickValuesPage.XBoxControllerClass.ReverseMinLeftThumbstickX = cb.IsChecked ?? false;//null ise false çevir.!
                }
                else if (cb == cb2)
                {
                    JoystickValuesPage.XBoxControllerClass.ReverseMinLeftThumbstickY = cb.IsChecked ?? false;
                }
                else if (cb == cb3)
                {
                    JoystickValuesPage.XBoxControllerClass.ReverseMinRightThumbstickX = cb.IsChecked ?? false;
                }
                else if (cb == cb4)
                {
                    JoystickValuesPage.XBoxControllerClass.ReverseMinRightThumbstickY = cb.IsChecked ?? false;
                }
                else if (cb == cb5)
                {
                    JoystickValuesPage.XBoxControllerClass.reverseMinLeftTrigger = cb.IsChecked ?? false;
                }
                else if (cb == cb6)
                {
                    JoystickValuesPage.XBoxControllerClass.ReverseMinRightTrigger = cb.IsChecked ?? false;
                }
            }
            else
            {
                if (cb == cb1)
                {
                    JoystickValuesPage.ExtremeControllerClass.ReverseX = cb.IsChecked ?? false;//null ise false çevir.!
                }
                else if (cb == cb2)
                {
                    JoystickValuesPage.ExtremeControllerClass.ReverseY = cb.IsChecked ?? false;
                }
                else if (cb == cb3)
                {
                    JoystickValuesPage.ExtremeControllerClass.ReverseZ = cb.IsChecked ?? false;
                }
                else if (cb == cb4)
                {
                    JoystickValuesPage.ExtremeControllerClass.ReverseHat = cb.IsChecked ?? false;
                }
                else if (cb == cb5)
                {
                    JoystickValuesPage.ExtremeControllerClass.ReverseThrottle = cb.IsChecked ?? false;
                }
            }
        }
        /// <summary>
        /// textChangedSettings Methodunu Her Metin Değiştiğinde Tetikleyen Method
        /// Bu Evente LimitSettings de Bulunan Tüm min trim max ve threshold textboxları Eklenmiştir.
        /// </summary>
        private void TextChanged(object sender, EventArgs e)
        {
            TextBox txtbx = (TextBox)sender;
            textChangedSettings(txtbx);
            if (true == uint.TryParse(txtbx.Text, out uint deger_u32) && (txtbx != min7 && txtbx != max7 && txtbx != trim7))
            {
                int minT, maxT;
                if (CommonMethods.KUMANDA_TIPI.XBOX_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick))
                {
                    minT = (int)JoystickValuesPage.XBoxControllerClass.MinThreshold;
                    maxT = (int)JoystickValuesPage.XBoxControllerClass.MaxThreshold;
                    if (!(deger_u32 >= minT && deger_u32 <= maxT))
                    {
                        var result = MessageBox.Show("Değer Geçerli Aralıkta Değil! Emin misiniz?",
                                     "Onay", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                        if (result == MessageBoxResult.No)
                        {
                            txtbx.Text = txtbx.Tag?.ToString();
                        }
                        else if (result == MessageBoxResult.Yes)
                        {
                            return;
                        }
                    }
                }
                else
                {
                    minT = (int)JoystickValuesPage.ExtremeControllerClass.MinThreshold;
                    maxT = (int)JoystickValuesPage.ExtremeControllerClass.MaxThreshold;
                    if (!(deger_u32 >= minT && deger_u32 <= maxT) && (txtbx != trim4 && txtbx != max4 && txtbx != min4 && txtbx != min5 && txtbx != max5) && !(deger_u32<65500))
                    {
                        var result = MessageBox.Show("Değer Geçerli Aralıkta Değil! Emin misiniz?",
                                     "Onay", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                        if (result == MessageBoxResult.No)
                        {
                            txtbx.Text = txtbx.Tag?.ToString();
                        }
                        else if (result == MessageBoxResult.Yes)
                        {
                            return;
                        }
                    }
                }
            }
        }
        /// <summary>
        ///TextBox'a tıklanınca, mevcut değeri Tag alanına kaydediyoruz.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox txtbx = (TextBox)sender;
            txtbx.Tag = txtbx.Text;
        }
        /// <summary>
        /// Her Threshold Butonuna Set Clicki Uygulandığında Threshold Değerlerini Güncelleyip Aralıkta Olmayanları Uyaran Event.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <summary>
        /// CheckAllTextBoxes Her Tıklandığında Aktif Eden Event.(ayc bknz:CheckAllTextBoxes())
        /// </summary>
        private void ApplyButton_Click(object sender, RoutedEventArgs e)
        {
            //Textboxlarda geçersiz değer varsa atama yapma
            if (!textChangedSettings(new TextBox()))
            {
                CommonMethods.CheckAllTextBoxes(this, JoystickValuesPage.ExtremeControllerClass, JoystickValuesPage.XBoxControllerClass, controller, extremeJoystick);
            }
            if (CommonMethods.NumberOfEmplyTextBox == tempTextBox)
            {
                error.Content = "";
            }
            else
            {
                error.Content = "Lütfen Boş Bırakılan Kısımları Doldurunuz!";
            }
            tempTextBox = CommonMethods.NumberOfEmplyTextBox;
        }
        /// <summary>
        /// Her x ve y StepSize Textboxları Değiştiğinde Tetiklenen Event.
        /// Stepsizeların Mevcut Min Max Aralığından Büyük Olup Olmadığını Kontrol Eder.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void TextChangedForStepSize(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(xStepSize.Text, out int x) && sender == xStepSize)
            {
                if (controller != null && controller.IsConnected)
                {
                    if (x <= (JoystickValuesPage.XBoxControllerClass.DPadMax - JoystickValuesPage.XBoxControllerClass.DPadMin))
                    {
                        JoystickValuesPage.XBoxControllerClass.XStepSize = (uint)x;
                        XstepSizeValuesLabel.Content = $"X Axis Step Size: {JoystickValuesPage.XBoxControllerClass.XStepSize}";
                        stepSizeErrorPanel1.Content = "";
                        xStepSize.Background = new SolidColorBrush(Colors.White);
                    }
                    else
                    {
                        stepSizeErrorPanel1.Content = "X stepsize değeri Mevcut Threshold aralığından büyük olamaz!";
                        xStepSize.Background = new SolidColorBrush(Colors.IndianRed);
                    }
                }
                else if (extremeJoystick != null)
                {
                    if (x <= (JoystickValuesPage.ExtremeControllerClass.MaxHat - JoystickValuesPage.ExtremeControllerClass.MinHat))
                    {
                        JoystickValuesPage.ExtremeControllerClass.XHatStepSize = (uint)x;
                        XstepSizeValuesLabel.Content = $"X Axis Step Size: {JoystickValuesPage.ExtremeControllerClass.XHatStepSize}";
                        stepSizeErrorPanel1.Content = "";
                        xStepSize.Background = new SolidColorBrush(Colors.White);
                    }
                    else
                    {
                        stepSizeErrorPanel1.Content = "X stepsize değeri mevcut aralıktan büyük olamaz!";
                        xStepSize.Background = new SolidColorBrush(Colors.IndianRed);
                    }
                }

            }

            else if (int.TryParse(yStepSize.Text, out int y) && sender == yStepSize)
            {
                if (controller != null && controller.IsConnected)
                {
                    if (y <= (JoystickValuesPage.XBoxControllerClass.DPadMax - JoystickValuesPage.XBoxControllerClass.DPadMin))
                    {
                        JoystickValuesPage.XBoxControllerClass.YStepSize = (uint)y;
                        YstepSizeValuesLabel.Content = $"Y Axis Step Size: {JoystickValuesPage.XBoxControllerClass.YStepSize}";
                        stepSizeErrorPanel.Content = "";
                        yStepSize.Background = new SolidColorBrush(Colors.White);
                    }
                    else
                    {
                        stepSizeErrorPanel.Content = "Y stepsize değeri Mevcut Threshold aralığından büyük olamaz!";
                        yStepSize.Background = new SolidColorBrush(Colors.IndianRed);
                    }
                }
                else if (extremeJoystick != null)
                {
                    if (y <= (JoystickValuesPage.ExtremeControllerClass.MaxHat - JoystickValuesPage.ExtremeControllerClass.MinHat))
                    {
                        JoystickValuesPage.ExtremeControllerClass.YHatStepSize = (uint)y;
                        YstepSizeValuesLabel.Content = $"Y Axis Step Size: {JoystickValuesPage.ExtremeControllerClass.YHatStepSize}";
                        stepSizeErrorPanel.Content = "";
                        yStepSize.Background = new SolidColorBrush(Colors.White);
                    }
                    else
                    {
                        stepSizeErrorPanel.Content = "Y stepsize değeri mevcut aralıktan büyük olamaz!";
                        yStepSize.Background = new SolidColorBrush(Colors.IndianRed);
                    }
                }
            }
        }
        /// <summary>
        /// İlgili Kontrolcü Classına Kaydedilmiş Ayarlamaları Json Formatta Serialize Eden(Kaydeden) Method.
        /// </summary>
        public void SaveSettings(object sender, RoutedEventArgs e)
        {
            string name = "";
            if (!string.IsNullOrWhiteSpace(pilotName.Text))
            {
                name = pilotName.Text;
                pilotError.Content = "";
            }
            else
            {
                pilotError.Content = "Lütfen Geçerli Bir İsim giriniz"; return;
            }
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "JSON Files (*.json)|*.json";
            saveFileDialog.Title = "Kaydetme Yeri Seç";

            if (saveFileDialog.ShowDialog() == true)
            {
                string filePath = saveFileDialog.FileName;
                if (CommonMethods.KUMANDA_TIPI.XBOX_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick))
                {
                    JoystickValuesPage.XBoxControllerClass.FunctionModeName = JoystickValuesPage.XBoxControllerClass.FunctionMode.ToString();
                    JoystickValuesPage.XBoxControllerClass.PilotName = name;
                    JoystickValuesPage.XBoxControllerClass.DateTime = DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss");
                    CommonMethods.SaveToFileXBox(filePath, JoystickValuesPage.XBoxControllerClass);
                }
                else if (CommonMethods.KUMANDA_TIPI.EXTREME_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick))
                {
                    JoystickValuesPage.ExtremeControllerClass.FunctionModeName = JoystickValuesPage.ExtremeControllerClass.FunctionMode.ToString();
                    JoystickValuesPage.ExtremeControllerClass.PilotName = name;
                    JoystickValuesPage.ExtremeControllerClass.DateTime = DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss");
                    CommonMethods.SaveToFileEx(filePath, JoystickValuesPage.ExtremeControllerClass);
                }

                pilotError.Content = ($"Veri {filePath} yoluna kaydedildi.");
            }
            else
            {
                pilotError.Content = ("Kaydetme iptal edildi.");
                JoystickValuesPage.LimitSettingsControl.PilotNameSection.Visibility = Visibility.Hidden;
                JoystickValuesPage.isVisible = false;
            }
        }
        /// <summary>
        /// Upload Edilen Kontrolcü Ayarlarını İlgili Bölümlere Yerleştiren Method.
        /// </summary>
        public void FillPageForControllers()
        {
            if (CommonMethods.KUMANDA_TIPI.XBOX_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick))
            {
                min1.Text = JoystickValuesPage.XBoxControllerClass.MinLeftThumbstickX.ToString();
                trim1.Text = JoystickValuesPage.XBoxControllerClass.TrimLeftThumbstickX.ToString();
                max1.Text = JoystickValuesPage.XBoxControllerClass.MaxLeftThumbstickX.ToString();
                cb1.IsChecked = JoystickValuesPage.XBoxControllerClass.ReverseMinLeftThumbstickX;
                min2.Text = JoystickValuesPage.XBoxControllerClass.MinLeftThumbstickY.ToString();
                trim2.Text = JoystickValuesPage.XBoxControllerClass.TrimLeftThumbstickY.ToString();
                max2.Text = JoystickValuesPage.XBoxControllerClass.MaxLeftThumbstickY.ToString();
                cb2.IsChecked = JoystickValuesPage.XBoxControllerClass.ReverseMinLeftThumbstickY;
                min3.Text = JoystickValuesPage.XBoxControllerClass.MinRightThumbstickX.ToString();
                trim3.Text = JoystickValuesPage.XBoxControllerClass.TrimRightThumbstickX.ToString();
                max3.Text = JoystickValuesPage.XBoxControllerClass.MaxRightThumbstickX.ToString();
                cb3.IsChecked = JoystickValuesPage.XBoxControllerClass.ReverseMinRightThumbstickX;
                min4.Text = JoystickValuesPage.XBoxControllerClass.MinRightThumbstickY.ToString();
                max4.Text = JoystickValuesPage.XBoxControllerClass.MaxRightThumbstickY.ToString();
                trim4.Text = JoystickValuesPage.XBoxControllerClass.TrimRightThumbstickY.ToString();
                cb4.IsChecked = JoystickValuesPage.XBoxControllerClass.ReverseMinRightThumbstickY;
                min5.Text = JoystickValuesPage.XBoxControllerClass.MinLeftTrigger.ToString();
                max5.Text = JoystickValuesPage.XBoxControllerClass.MaxLeftTrigger.ToString();
                cb5.IsChecked = JoystickValuesPage.XBoxControllerClass.reverseMinLeftTrigger;
                min6.Text = JoystickValuesPage.XBoxControllerClass.MinRightTrigger.ToString();
                max6.Text = JoystickValuesPage.XBoxControllerClass.MaxRightTrigger.ToString();
                cb6.IsChecked = JoystickValuesPage.XBoxControllerClass.ReverseMinRightTrigger;
                xStepSize.Text = JoystickValuesPage.XBoxControllerClass.XStepSize.ToString();
                yStepSize.Text = JoystickValuesPage.XBoxControllerClass.YStepSize.ToString();
                XstepSizeValuesLabel.Content = $"X Axis Step Size: {JoystickValuesPage.XBoxControllerClass.XStepSize}";
                YstepSizeValuesLabel.Content = $"Y Axis Step Size: {JoystickValuesPage.XBoxControllerClass.YStepSize}";
                pilotName.Text = JoystickValuesPage.XBoxControllerClass.PilotName;
                JoystickValuesPage.FunctionsSettingsControl.leftVib.Text = JoystickValuesPage.XBoxControllerClass.LeftVibrationValue.ToString();
                JoystickValuesPage.FunctionsSettingsControl.rightVib.Text = JoystickValuesPage.XBoxControllerClass.RightVibrationValue.ToString();
                min7.Text = JoystickValuesPage.XBoxControllerClass.DPadMin.ToString();
                max7.Text = JoystickValuesPage.XBoxControllerClass.DPadMax.ToString();
            }
            else if (CommonMethods.KUMANDA_TIPI.EXTREME_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick))
            {
                min1.Text = JoystickValuesPage.ExtremeControllerClass.MinX.ToString();
                trim1.Text = JoystickValuesPage.ExtremeControllerClass.TrimValueX.ToString();
                max1.Text = JoystickValuesPage.ExtremeControllerClass.MaxX.ToString();
                cb1.IsChecked = JoystickValuesPage.ExtremeControllerClass.ReverseX;
                min2.Text = JoystickValuesPage.ExtremeControllerClass.MinY.ToString();
                trim2.Text = JoystickValuesPage.ExtremeControllerClass.TrimValueY.ToString();
                max2.Text = JoystickValuesPage.ExtremeControllerClass.MaxY.ToString();
                cb2.IsChecked = JoystickValuesPage.ExtremeControllerClass.ReverseY;
                min3.Text = JoystickValuesPage.ExtremeControllerClass.MinZ.ToString();
                trim3.Text = JoystickValuesPage.ExtremeControllerClass.TrimValueZ.ToString();
                max3.Text = JoystickValuesPage.ExtremeControllerClass.MaxZ.ToString();
                cb3.IsChecked = JoystickValuesPage.ExtremeControllerClass.ReverseZ;
                min4.Text = JoystickValuesPage.ExtremeControllerClass.MinHat.ToString();
                max4.Text = JoystickValuesPage.ExtremeControllerClass.MaxHat.ToString();
                min5.Text = JoystickValuesPage.ExtremeControllerClass.MinThrottle.ToString();
                max5.Text = JoystickValuesPage.ExtremeControllerClass.MaxThrottle.ToString();
                cb4.IsChecked = JoystickValuesPage.ExtremeControllerClass.ReverseThrottle;
                xStepSize.Text = JoystickValuesPage.ExtremeControllerClass.XHatStepSize.ToString();
                yStepSize.Text = JoystickValuesPage.ExtremeControllerClass.YHatStepSize.ToString();
                XstepSizeValuesLabel.Content = $"X Axis Step Size: {JoystickValuesPage.ExtremeControllerClass.XHatStepSize}";
                YstepSizeValuesLabel.Content = $"Y Axis Step Size: {JoystickValuesPage.ExtremeControllerClass.YHatStepSize}";
                pilotName.Text = JoystickValuesPage.ExtremeControllerClass.PilotName;
            }
        }
        /// <summary>
        /// seçilen TextBox İçindeki Textleri Otomotik silen ve tüm TextBoxların Bağlı Olduğu Event
        /// </summary>
        private void NumberTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }
    }
}
