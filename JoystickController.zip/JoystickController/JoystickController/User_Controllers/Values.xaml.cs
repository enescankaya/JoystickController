﻿using JoystickController.Binding_Classes;
using JoystickController.Interfaces;
using SharpDX.DirectInput;
using SharpDX.XInput;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;

namespace JoystickController.User_Controllers
{
    /// <summary>
    ///Değer Listeleme İçin Kullanılmaktadır
    /// </summary>
    public partial class Values : UserControl
    {
        #region PARAMETERS
        ObservableCollection<InputState> inputValues = [];
        private Controller controller;
        private DirectInput directInput;
        private Joystick extremeJoystick;
        JoystickValuesPage JoystickValuesPage;
        #endregion
        public Values()
        {
            InitializeComponent();
            ButtonValuesList.ItemsSource = inputValues;
        }
        /// <summary>
        /// XBox Controller İçin Controller index ayarlaması yapar, Kullanılan JoystickValuesPage Referansını Gönderir.
        /// Referans Değerini MainPage deki Mevcut Classlara Ulaşabilmek İçin Kullanıyoruz.
        /// </summary>
        /// <param name="index">XBox Controller İçin Kullanılan Controller İndexi</param>
        /// <param name="jvp">JoystickValuesPage</param>
        public void setControllerForXbox(int index, JoystickValuesPage jvp)
        {
            controller = new Controller((UserIndex)index);
            JoystickValuesPage = jvp;
        }
        /// <summary>
        /// Extreme Controller İçin Controller ayarlaması yapar, Kullanılan JoystickValuesPage Referansını Gönderir.
        /// Referans Değerini MainPage deki Mevcut Classlara Ulaşabilmek İçin Kullanıyoruz.
        /// </summary>
        /// <param name="joystick">Extreme Controller İçin Kullanılan Controller Referansı</param>
        /// <param name="jvp">JoystickValuesPage</param>
        public void setControllerForExtreme(Joystick joystick, JoystickValuesPage jvp)
        {
            extremeJoystick = joystick;
            JoystickValuesPage = jvp;
        }

        /// <summary>
        /// XBox DPad Butonlarını Step Artış için Ayrı Kontrol Ediyoruz.
        /// XBox DPad butonların durumlarını kontrol edip Anlık Olarak XBox Class'daki DPadY ve DPadX değerlerini Günceller.
        /// </summary>
        /// <param name="cXBox"></param>
        public void CheckDPadButtons()
        {
            try
            {
                var state = controller.GetState();
                GamepadButtonFlags buttons = state.Gamepad.Buttons;
                if ((buttons & GamepadButtonFlags.DPadUp) != 0 && JoystickValuesPage.XBoxControllerClass.DPadY <= JoystickValuesPage.XBoxControllerClass.DPadMax - JoystickValuesPage.XBoxControllerClass.YStepSize)
                {
                    JoystickValuesPage.XBoxControllerClass.DPadY += JoystickValuesPage.XBoxControllerClass.YStepSize;
                }
                if ((buttons & GamepadButtonFlags.DPadDown) != 0 && JoystickValuesPage.XBoxControllerClass.DPadY >= JoystickValuesPage.XBoxControllerClass.DPadMin + JoystickValuesPage.XBoxControllerClass.YStepSize)
                {
                    JoystickValuesPage.XBoxControllerClass.DPadY -= JoystickValuesPage.XBoxControllerClass.YStepSize;
                }
                if ((buttons & GamepadButtonFlags.DPadRight) != 0 && JoystickValuesPage.XBoxControllerClass.DPadX <= JoystickValuesPage.XBoxControllerClass.DPadMax - JoystickValuesPage.XBoxControllerClass.XStepSize)
                {
                    JoystickValuesPage.XBoxControllerClass.DPadX += JoystickValuesPage.XBoxControllerClass.XStepSize;
                }
                if ((buttons & GamepadButtonFlags.DPadLeft) != 0 && JoystickValuesPage.XBoxControllerClass.DPadX >= JoystickValuesPage.XBoxControllerClass.DPadMin + JoystickValuesPage.XBoxControllerClass.XStepSize)
                {
                    JoystickValuesPage.XBoxControllerClass.DPadX -= JoystickValuesPage.XBoxControllerClass.XStepSize;
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }

        }
        /// <summary>
        /// XBox Kontrolcü Değerlerini ListView'e Aktarabilmek İçin inputValues Parametresine Aktarıldığı Method.
        /// </summary>
        /// <param name="inputValues">DataBinding İçin ListView'in ItemSource'una Bağlanan Parametre</param>
        /// <param name="buttons">Buton Değerlerini Almak İçin Alınan Parametre</param>
        private void AddButtonStatesXBox(ICollection<InputState> inputValues, GamepadButtonFlags buttons)
        {
            CheckDPadButtons();
            inputValues.Add(new InputState
            {
                Input = "D-Pad Y",
                NewValue = JoystickValuesPage.XBoxControllerClass.DPadY.ToString(),
                Min = JoystickValuesPage.XBoxControllerClass.DPadMin.ToString(),
                Max = JoystickValuesPage.XBoxControllerClass.DPadMax.ToString()
            });
            inputValues.Add(new InputState
            {
                Input = "D-Pad X",
                NewValue = JoystickValuesPage.XBoxControllerClass.DPadX.ToString(),
                Min = JoystickValuesPage.XBoxControllerClass.DPadMin.ToString(),
                Max = JoystickValuesPage.XBoxControllerClass.DPadMax.ToString()
            });
            inputValues.Add(new InputState
            {
                Input = "Start",
                NewValue = (buttons & GamepadButtonFlags.Start) != 0 ? "1" : "0",
                Min = "0",
                Max = "1"
            });
            inputValues.Add(new InputState
            {
                Input = "Back",
                NewValue = (buttons & GamepadButtonFlags.Back) != 0 ? "1" : "0",
                Min = "0",
                Max = "1"
            });
            inputValues.Add(new InputState
            {
                Input = "Left Thumb",
                NewValue = (buttons & GamepadButtonFlags.LeftThumb) != 0 ? "1" : "0",
                Min = "0",
                Max = "1"
            });
            inputValues.Add(new InputState
            {
                Input = "Right Thumb",
                NewValue = (buttons & GamepadButtonFlags.RightThumb) != 0 ? "1" : "0",
                Min = "0",
                Max = "1"
            });
            inputValues.Add(new InputState
            {
                Input = "Left Shoulder",
                NewValue = (buttons & GamepadButtonFlags.LeftShoulder) != 0 ? "1" : "0",
                Min = "0",
                Max = "1"
            });
            inputValues.Add(new InputState
            {
                Input = "Right Shoulder",
                NewValue = (buttons & GamepadButtonFlags.RightShoulder) != 0 ? "1" : "0",
                Min = "0",
                Max = "1"
            });
            inputValues.Add(new InputState
            {
                Input = "A",
                NewValue = (buttons & GamepadButtonFlags.A) != 0 ? "1" : "0",
                Min = "0",
                Max = "1"
            });
            inputValues.Add(new InputState
            {
                Input = "B",
                NewValue = (buttons & GamepadButtonFlags.B) != 0 ? "1" : "0",
                Min = "0",
                Max = "1"
            });
            inputValues.Add(new InputState
            {
                Input = "X",
                NewValue = (buttons & GamepadButtonFlags.X) != 0 ? "1" : "0",
                Min = "0",
                Max = "1"
            });
            inputValues.Add(new InputState
            {
                Input = "Y",
                NewValue = (buttons & GamepadButtonFlags.Y) != 0 ? "1" : "0",
                Min = "0",
                Max = "1"
            });
        }
        /// <summary>
        /// Tüm Joystick Değerlerini Mevcut Bağlı Kontrolcüye Göre ListView'a Aktaraf Method.
        /// </summary>
        public void ShowJoystickValues()
        {
            inputValues.Clear();
            if (CommonMethods.KUMANDA_TIPI.XBOX_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick))
            {
                if (controller == null)
                {
                    ControllerTypeLabel.Text = "Joystick bağlantısı yok !!!";
                    return;
                }
                else
                {
                    var state = controller.GetState();

                    inputValues.Add(new InputState
                    {
                        Input = "Left Thumbstick X",
                        NewValue = SetLimitsForXBoxController(state.Gamepad.LeftThumbX, (int)JoystickValuesPage.XBoxControllerClass.MinLeftThumbstickX, JoystickValuesPage.XBoxControllerClass.TrimLeftThumbstickX, JoystickValuesPage.XBoxControllerClass.MaxLeftThumbstickX, false, JoystickValuesPage.XBoxControllerClass.ReverseMinLeftThumbstickX),
                        Min = JoystickValuesPage.XBoxControllerClass.MinLeftThumbstickX.ToString(),
                        Max = JoystickValuesPage.XBoxControllerClass.MaxLeftThumbstickX.ToString()
                    });
                    inputValues.Add(new InputState
                    {
                        Input = "Left Thumbstick Y",
                        NewValue = SetLimitsForXBoxController(state.Gamepad.LeftThumbY, (int)JoystickValuesPage.XBoxControllerClass.MinLeftThumbstickY, JoystickValuesPage.XBoxControllerClass.TrimLeftThumbstickY, JoystickValuesPage.XBoxControllerClass.MaxLeftThumbstickY, false, JoystickValuesPage.XBoxControllerClass.ReverseMinLeftThumbstickY),
                        Min = JoystickValuesPage.XBoxControllerClass.MinLeftThumbstickY.ToString(),
                        Max = JoystickValuesPage.XBoxControllerClass.MaxLeftThumbstickY.ToString()
                    });
                    inputValues.Add(new InputState
                    {
                        Input = "Right Thumbstick X",
                        NewValue = SetLimitsForXBoxController(state.Gamepad.RightThumbX, (int)JoystickValuesPage.XBoxControllerClass.MinRightThumbstickX, JoystickValuesPage.XBoxControllerClass.TrimRightThumbstickX, JoystickValuesPage.XBoxControllerClass.MaxRightThumbstickX, false, JoystickValuesPage.XBoxControllerClass.ReverseMinRightThumbstickX),
                        Min = JoystickValuesPage.XBoxControllerClass.MinRightThumbstickX.ToString(),
                        Max = JoystickValuesPage.XBoxControllerClass.MaxRightThumbstickX.ToString()
                    });
                    inputValues.Add(new InputState
                    {
                        Input = "Right Thumbstick Y",
                        NewValue = SetLimitsForXBoxController(state.Gamepad.RightThumbY, (int)JoystickValuesPage.XBoxControllerClass.MinRightThumbstickY, JoystickValuesPage.XBoxControllerClass.TrimRightThumbstickY, JoystickValuesPage.XBoxControllerClass.MaxRightThumbstickY, false, JoystickValuesPage.XBoxControllerClass.ReverseMinRightThumbstickY),
                        Min = JoystickValuesPage.XBoxControllerClass.MinRightThumbstickY.ToString(),
                        Max = JoystickValuesPage.XBoxControllerClass.MaxRightThumbstickY.ToString()
                    });
                    inputValues.Add(new InputState
                    {
                        Input = "Left Trigger",
                        NewValue = SetLimitsForXBoxController(state.Gamepad.LeftTrigger, (int)JoystickValuesPage.XBoxControllerClass.MinLeftTrigger, 1, JoystickValuesPage.XBoxControllerClass.MaxLeftTrigger, true, JoystickValuesPage.XBoxControllerClass.reverseMinLeftTrigger),
                        Min = JoystickValuesPage.XBoxControllerClass.MinLeftTrigger.ToString(),
                        Max = JoystickValuesPage.XBoxControllerClass.MaxLeftTrigger.ToString()
                    });
                    inputValues.Add(new InputState
                    {
                        Input = "Right Trigger",
                        NewValue = SetLimitsForXBoxController(state.Gamepad.RightTrigger, (int)JoystickValuesPage.XBoxControllerClass.MinRightTrigger, 1, JoystickValuesPage.XBoxControllerClass.MaxRightTrigger, true, JoystickValuesPage.XBoxControllerClass.ReverseMinRightTrigger),
                        Min = JoystickValuesPage.XBoxControllerClass.MinRightTrigger.ToString(),
                        Max = JoystickValuesPage.XBoxControllerClass.MaxRightTrigger.ToString()
                    });
                    AddButtonStatesXBox(inputValues, state.Gamepad.Buttons);

                }
            }

            else if (CommonMethods.KUMANDA_TIPI.EXTREME_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick))
            {
                try
                {
                    var state = extremeJoystick.GetCurrentState();
                    inputValues.Add(new InputState
                    {
                        Input = "X Axis",
                        NewValue = SetLimitsForExtremeController(state.X, JoystickValuesPage.ExtremeControllerClass.MinX, JoystickValuesPage.ExtremeControllerClass.TrimValueX, JoystickValuesPage.ExtremeControllerClass.MaxX, "", false, JoystickValuesPage.ExtremeControllerClass.ReverseX),
                        Min = JoystickValuesPage.ExtremeControllerClass.MinX.ToString(),
                        Max = JoystickValuesPage.ExtremeControllerClass.MaxX.ToString()
                    });

                    inputValues.Add(new InputState
                    {
                        Input = "Y Axis",
                        NewValue = SetLimitsForExtremeController(state.Y, JoystickValuesPage.ExtremeControllerClass.MinY, JoystickValuesPage.ExtremeControllerClass.TrimValueY, JoystickValuesPage.ExtremeControllerClass.MaxY, "", false, JoystickValuesPage.ExtremeControllerClass.ReverseY),
                        Min = JoystickValuesPage.ExtremeControllerClass.MinY.ToString(),
                        Max = JoystickValuesPage.ExtremeControllerClass.MaxY.ToString()
                    });

                    inputValues.Add(new InputState
                    {
                        Input = "Z Axis",
                        NewValue = SetLimitsForExtremeController(state.RotationZ, JoystickValuesPage.ExtremeControllerClass.MinZ, JoystickValuesPage.ExtremeControllerClass.TrimValueZ, JoystickValuesPage.ExtremeControllerClass.MaxZ, "", false, JoystickValuesPage.ExtremeControllerClass.ReverseZ),
                        Min = JoystickValuesPage.ExtremeControllerClass.MinZ.ToString(),
                        Max = JoystickValuesPage.ExtremeControllerClass.MaxZ.ToString()
                    });

                    SetLimitsForExtremeController(state.PointOfViewControllers[0], JoystickValuesPage.ExtremeControllerClass.MinHat, JoystickValuesPage.ExtremeControllerClass.TrimValueHat, JoystickValuesPage.ExtremeControllerClass.MaxHat, "X", false, JoystickValuesPage.ExtremeControllerClass.ReverseHat);
                    SetLimitsForExtremeController(state.PointOfViewControllers[0], JoystickValuesPage.ExtremeControllerClass.MinHat, JoystickValuesPage.ExtremeControllerClass.TrimValueHat, JoystickValuesPage.ExtremeControllerClass.MaxHat, "Y", false, JoystickValuesPage.ExtremeControllerClass.ReverseHat);

                    inputValues.Add(new InputState
                    {
                        Input = "Hat Switch X",
                        NewValue = JoystickValuesPage.ExtremeControllerClass.XValueHat.ToString(),
                        Min = JoystickValuesPage.ExtremeControllerClass.MinHat.ToString(),
                        Max = JoystickValuesPage.ExtremeControllerClass.MaxHat.ToString()
                    });

                    inputValues.Add(new InputState
                    {
                        Input = "Hat Switch Y",
                        NewValue = JoystickValuesPage.ExtremeControllerClass.YValueHat.ToString(),
                        Min = JoystickValuesPage.ExtremeControllerClass.MinHat.ToString(),
                        Max = JoystickValuesPage.ExtremeControllerClass.MaxHat.ToString()
                    });

                    inputValues.Add(new InputState
                    {
                        Input = "Throttle",
                        NewValue = SetLimitsForExtremeController(state.Sliders[0], JoystickValuesPage.ExtremeControllerClass.MinThrottle, 0, JoystickValuesPage.ExtremeControllerClass.MaxThrottle, "", true, JoystickValuesPage.ExtremeControllerClass.ReverseThrottle),
                        Min = JoystickValuesPage.ExtremeControllerClass.MinThrottle.ToString(),
                        Max = JoystickValuesPage.ExtremeControllerClass.MaxThrottle.ToString()
                    });

                    for (int i = 0; i <= 11; i++)
                    {
                        if (i < state.Buttons.Length)
                        {
                            inputValues.Add(new InputState { Input = $"Button {i + 1}", NewValue = state.Buttons[i] ? "1" : "0", Min = "0", Max = "1" });
                        }
                    }

                }
                catch (SharpDX.SharpDXException ex) when (ex.HResult == unchecked((int)0x8007001E))
                {
                    ControllerTypeLabel.Text = "Joystick bağlantısı kaybedildi. Lütfen Sistemi Yeniden Başlatınız.";
                    return;
                }
                catch (Exception ex)
                {
                    ControllerTypeLabel.Text = "Bir hata oluştu: " + ex.Message;
                    return;
                }
            }
        }
        /// <summary>
        /// State Değişkenini İstenilen min,trim,max Değerleri Arasına Çeviren Fonksiyon
        /// </summary>
        /// <param name="state">Maplamak İstediğimiz Değer</param>
        /// <param name="min"></param>
        /// <param name="trim"></param>
        /// <param name="max"></param>
        /// <param name="isTrigger">Gelen Değerin Trigger Olup Olmadıgını Kontrol Eden Parametre.</param>
        /// <param name="isReversed">İstenilen Değerin Reverse İstenip İstenmediği Durum Kontrolcüsü</param>
        /// <returns>String Tipi</returns>
        public string SetLimitsForXBoxController(int state, int min, uint trim, uint max, bool isTrigger, bool isReversed)
        {
            if (isTrigger)
            {
                if (isReversed)
                {
                    return Map(255 - state, 0, 255, (int)min, (int)max).ToString();
                }
                return Map(state, 0, 255, (int)min, (int)max).ToString();
            }
            else if (state <= -1000)
            {
                if (isReversed)
                {
                    return Map(state, -1000, -32767, (int)trim, (int)max).ToString();
                }
                return Map(state, -32767, -1000, (int)min, (int)trim).ToString();
            }
            else if (state >= 1000)
            {
                if (isReversed)
                {
                    return Map(state, 32767, 1000, (int)min, (int)trim).ToString();
                }
                return Map(state, 1000, 32767, (int)trim, (int)max).ToString();
            }
            return trim.ToString();
        }
        /// <summary>
        /// State Değişkenini İstenilen min,trim,max Değerleri Arasına Çeviren Fonksiyon
        /// XBox İle Extreme Farklı Değerler Döndürdüğü İçin Ortak SetLimit Methodu Kullanılamamaktadır
        /// </summary>
        /// <param name="state">Maplamak İstediğimiz Değer</param>
        /// <param name="min"></param>
        /// <param name="trim"></param>
        /// <param name="max"></param>
        /// <param name="isHatSwitch">Gelen Değerin HatSwitch Olup Olmadıgını Kontrol Eden Parametre</param>
        /// <param name="isThrottle">Gelen Değerin Throttle Olup Olmadıgını Kontrol Eden Parametre</param>
        /// <param name="isReversed">İstenilen Değerin Reverse İstenip İstenmediği Durum Kontrolcüsü</param>
        /// <param name="cExtreme"></param>
        /// <returns>String Tipi</returns>
        public string SetLimitsForExtremeController(int state, uint min, uint trim, uint max, string isHatSwitch, bool isThrottle, bool isReversed)
        {
            if (isThrottle)
            {
                if (isReversed)
                {
                    return Map(65535 - state, 0, 65535, (int)min, (int)max).ToString();
                }
                return Map(state, 0, 65535, (int)min, (int)max).ToString();

            }
            else if (isHatSwitch == "X" || isHatSwitch == "Y")
            {
                if (state == -1)
                {
                    if (isHatSwitch == "X") { return JoystickValuesPage.ExtremeControllerClass.XValueHat.ToString(); }
                    else { return JoystickValuesPage.ExtremeControllerClass.YValueHat.ToString(); }
                }

                // X için artış
                if ((state == 9000) && JoystickValuesPage.ExtremeControllerClass.XValueHat <= JoystickValuesPage.ExtremeControllerClass.MaxHat - JoystickValuesPage.ExtremeControllerClass.XHatStepSize)
                {
                    JoystickValuesPage.ExtremeControllerClass.XValueHat += JoystickValuesPage.ExtremeControllerClass.XHatStepSize;

                }
                // X için azalış
                if ((state == 27000) && JoystickValuesPage.ExtremeControllerClass.XValueHat >= JoystickValuesPage.ExtremeControllerClass.MinHat + JoystickValuesPage.ExtremeControllerClass.XHatStepSize)
                {
                    JoystickValuesPage.ExtremeControllerClass.XValueHat -= JoystickValuesPage.ExtremeControllerClass.XHatStepSize;
                }
                // Y için artış 
                if ((state == 0) && (JoystickValuesPage.ExtremeControllerClass.YValueHat <= JoystickValuesPage.ExtremeControllerClass.MaxHat - JoystickValuesPage.ExtremeControllerClass.YHatStepSize))
                {
                    JoystickValuesPage.ExtremeControllerClass.YValueHat += JoystickValuesPage.ExtremeControllerClass.YHatStepSize;
                }
                // Y için azalış
                if ((state == 18000) && (JoystickValuesPage.ExtremeControllerClass.YValueHat >= JoystickValuesPage.ExtremeControllerClass.MinHat + JoystickValuesPage.ExtremeControllerClass.YHatStepSize))
                {
                    JoystickValuesPage.ExtremeControllerClass.YValueHat -= JoystickValuesPage.ExtremeControllerClass.YHatStepSize;
                }
            }

            else if (state < 32000)
            {
                if (isReversed)
                {
                    return Map(state, 32767, 0, (int)trim, (int)max).ToString();
                }
                return Map(state, 0, 32767, (int)min, (int)trim).ToString();
            }
            else if (state > 34000)
            {
                if (isReversed)
                {
                    return Map(state, 65535, 34000, (int)min, (int)trim).ToString();
                }
                return Map(state, 34000, 65535, (int)trim, (int)max).ToString();
            }
            return trim.ToString();
        }
        /// <summary>
        /// OldMin ile OldMax Arasındaki Value Değerini newMin ile newMax Aralığına Çevirip döndüren Method.
        /// </summary>
        /// <param name="value"></param>
        /// <param name="oldMin">Value Mevcut Min Değeri</param>
        /// <param name="oldMax">Value Mevcut Max Değeri</param>
        /// <param name="newMin">Value İstenilen Yeni Min Değeri</param>
        /// <param name="newMax">Value İstenilen Yeni Max Değeri</param>
        /// <returns>İnt Tipi</returns>
        public int Map(int value, int oldMin, int oldMax, int newMin, int newMax)
        {
            return (int)((value - oldMin) * ((newMax) - (newMin)) / (oldMax - oldMin) + (newMin));
        }
    }
}
