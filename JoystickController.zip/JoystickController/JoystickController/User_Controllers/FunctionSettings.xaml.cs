﻿using JoystickController.Function_Classes;
using JoystickController.Interfaces;
using JoystickController.Joystick_Controllers;
using SharpDX.DirectInput;
using SharpDX.XInput;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
namespace JoystickController.User_Controllers
{
    /// <summary>
    /// FunctionSettings.xaml etkileşim mantığı
    /// </summary>
    public partial class FunctionSettings : UserControl
    {
        #region PARAMETERS
        private RandomFunctionsGimball gimbalFunctions;
        private RandomFunctionsIha ihaFunctions;
        private Controller controller;
        private Joystick extremeJoystick;
        public List<ComboBox> functionsListComboboxes;
        public List<UserControl> RowControlUserList;
        JoystickValuesPage JoystickValuesPage;
        public ObservableCollection<object>? bothFunctionsList = [];
        public CommonMethods.FunctionMode modeIndex;
        private List<Point> XBoxButtonPoints = [];
        #endregion
        /// <summary>
        /// XBox Controller İçin Controller index ayarlaması yapar, Kullanılan JoystickValuesPage Referansını Gönderir.
        /// Referans Değerini MainPage deki Mevcut Classlara Ulaşabilmek İçin Kullanıyoruz.
        /// </summary>
        /// <param name="index">XBox Controller İçin Kullanılan Controller İndexi</param>
        /// <param name="jvp">JoystickValuesPage</param>
        public void setControllerForXbox(int index, JoystickValuesPage jvp)
        {
            TakeXboxButtonValues();
            TakeXboxButtonPoints();
            controller = new Controller((UserIndex)index);
            JoystickValuesPage = jvp;
            modeIndex = JoystickValuesPage.XBoxControllerClass.FunctionMode;
            gimbalFunctions = new RandomFunctionsGimball();
            ihaFunctions = new RandomFunctionsIha();
            StartVibration(zaman_sn_s32: 1);
        }
        public void setControllerForExtreme(Joystick joystick, JoystickValuesPage jvp)
        {
            TakeExtremeButtonValues();
            r_14.Visibility = Visibility.Collapsed;
            r_13.Visibility = Visibility.Collapsed;
            Clean_CheckBoxes_For_ExtremeJoystick();
            extremeJoystick = joystick;
            JoystickValuesPage = jvp;
            modeIndex = JoystickValuesPage.ExtremeControllerClass.FunctionMode;
            gimbalFunctions = new RandomFunctionsGimball();
            ihaFunctions = new RandomFunctionsIha();
            vibrationStackPanel.Visibility = Visibility.Collapsed;

        }
        private async void Vibration_Click(object sender, RoutedEventArgs e)
        {
            if (uint.TryParse(rightVib.Text, out uint valueR) && uint.TryParse(leftVib.Text, out uint valueL))
            {
                JoystickValuesPage.XBoxControllerClass.RightVibrationValue = valueR;
                JoystickValuesPage.XBoxControllerClass.LeftVibrationValue = valueL;
                SetVibration(valueL, valueR);
                await Task.Delay(1000);
                SetVibration(0, 0);
            }
            else
            {
                VibrationErrorLabel.Content = "lütfen geçerli bir değer giriniz!";
            }
        }
        public void SetVibration(uint left, uint right)
        {
            if (controller != null)
            {
                if (left < 11 && left >= 0 && right < 11 && right >= 0)
                {
                    var vibration = new SharpDX.XInput.Vibration
                    {
                        LeftMotorSpeed = (ushort)((left) * 6553.5),
                        RightMotorSpeed = (ushort)((right) * 6553.5)
                    };

                    controller.SetVibration(vibration);
                }
                else
                {
                    VibrationErrorLabel.Content = "lütfen geçerli bir aralık giriniz!";

                }
            }
            else
            {
                MessageBox.Show("Error! Vibrasyon için Kontrolcü bağlı değil.");
            }
        }
        /// <summary>
        /// XBox Kontroller Seçildiğinde 1 Saniye Kontrolcü Class'ındaki değerlere Göre Titeşim Almak İçin Çağırıyoruz.
        /// </summary>
        /// <param name="zaman_sn_s32"> Tür</param>
        public async void StartVibration(int zaman_sn_s32)
        {
            SetVibration(JoystickValuesPage.XBoxControllerClass.LeftVibrationValue, JoystickValuesPage.XBoxControllerClass.RightVibrationValue);
            await Task.Delay(zaman_sn_s32 * 300);
            SetVibration(0, 0);
        }
        /// <summary>
        /// Extreme Controller İçin Controller ayarlaması yapar, Kullanılan JoystickValuesPage Referansını Gönderir.
        /// Referans Değerini MainPage deki Mevcut Classlara Ulaşabilmek İçin Kullanıyoruz.
        /// </summary>
        /// <param name="joystick">Extreme Controller İçin Kullanılan Controller Referansı</param>
        /// <param name="jvp">JoystickValuesPage</param>

        public FunctionSettings()
        {
            InitializeComponent();
            AddFunctionComboboxesToList();
            AddRowControllerTolist();
            //AddProgresbarsToList();
        }
        /// <summary>
        /// Extremede Vibration Ayarı Olmadığı İçin Vibration ile ilgili CheckBoxları Görünmez Yapar
        /// </summary>
        public void Clean_CheckBoxes_For_ExtremeJoystick()
        {
            VibrationHeader.Visibility = Visibility.Collapsed;
            r_1.CheckBox.Visibility = Visibility.Collapsed;
            r_2.CheckBox.Visibility = Visibility.Collapsed;
            r_3.CheckBox.Visibility = Visibility.Collapsed;
            r_4.CheckBox.Visibility = Visibility.Collapsed;
            r_5.CheckBox.Visibility = Visibility.Collapsed;
            r_6.CheckBox.Visibility = Visibility.Collapsed;
            r_7.CheckBox.Visibility = Visibility.Collapsed;
            r_8.CheckBox.Visibility = Visibility.Collapsed;
            r_9.CheckBox.Visibility = Visibility.Collapsed;
            r_10.CheckBox.Visibility = Visibility.Collapsed;
            r_11.CheckBox.Visibility = Visibility.Collapsed;
            r_12.CheckBox.Visibility = Visibility.Collapsed;
            r_13.CheckBox.Visibility = Visibility.Collapsed;
            r_14.CheckBox.Visibility = Visibility.Collapsed;
        }
        /// <summary>
        /// Fonksiyonları Listelemek İçin Kullanılan ComboBoxları Daha Sonra Kullanabilmek İçin Listeler
        /// </summary>
        public void AddFunctionComboboxesToList()
        {
            functionsListComboboxes =
            [
                r_1.ComboBox,
                r_2.ComboBox,
                r_3.ComboBox,
                r_4.ComboBox,
                r_5.ComboBox,
                r_6.ComboBox,
                r_7.ComboBox,
                r_8.ComboBox,
                r_9.ComboBox,
                r_10.ComboBox,
                r_11.ComboBox,
                r_12.ComboBox,
                r_13.ComboBox,
                r_14.ComboBox,

            ];

        }
        /// <summary>
        /// Butonları Listelemek İçin Kullanılan ComboBoxları Daha Sonra Kullanabilmek İçin Listeler
        /// </summary>
        public void AddRowControllerTolist()
        {
            RowControlUserList =
            [
                r_1,
                r_2,
                r_3,
                r_4,
                r_5,
                r_6,
                r_8,
                r_7,
                r_9,
                r_10,
                r_11,
                r_12,
                r_13,
                r_14,
            ];

        }
        /// <summary>
        ///Listelemek İçin Extreme Kontrolcü Buton Değerlerini Ayarlar
        /// </summary>
        public void TakeExtremeButtonValues()
        {
            int Counter = 1;
            foreach (FunctionRowController usercontrol in RowControlUserList)
            {
                usercontrol.Label.Content = ($"Button {Counter++}");
            }
        }
        /// <summary>
        ///Listelemek İçin Xbox Kontrolcü Buton Değerlerini Ayarlar
        /// </summary>
        public void TakeXboxButtonValues()
        {
            r_1.Label.Content = ("D-Pad Up");
            r_2.Label.Content = ("D-Pad Left");
            r_3.Label.Content = ("D-Pad Right");
            r_4.Label.Content = ("D-Pad Down");
            r_5.Label.Content = ("Start");
            r_6.Label.Content = ("Back");
            r_7.Label.Content = ("Left Thumb");
            r_8.Label.Content = ("Right Thumb");
            r_9.Label.Content = ("Left Shoulder");
            r_10.Label.Content = ("Right Shoulder");
            r_11.Label.Content = ("A");
            r_12.Label.Content = ("B");
            r_13.Label.Content = ("X");
            r_14.Label.Content = ("Y");

        }
        public void TakeXboxButtonPoints()
        {
            XBoxButtonPoints.Add(new Point(450, 480));//"D-Pad Up"
            XBoxButtonPoints.Add(new Point(370, 560));//D-Pad Left
            XBoxButtonPoints.Add(new Point(530, 560));  //D-Pad Right
            XBoxButtonPoints.Add(new Point(456, 634));  //D-Pad Down
            XBoxButtonPoints.Add(new Point(842, 250));  //Start
            XBoxButtonPoints.Add(new Point(430, 250));  //Back
            XBoxButtonPoints.Add(new Point(295, 380));  //Left Thumb
            XBoxButtonPoints.Add(new Point(817, 555));  //Right Thumb
            XBoxButtonPoints.Add(new Point(265, 168));  //Left Shoulder
            XBoxButtonPoints.Add(new Point(996, 168));  //Right Shoulder
            XBoxButtonPoints.Add(new Point(970, 466));  //A
            XBoxButtonPoints.Add(new Point(1054, 386));  //B
            XBoxButtonPoints.Add(new Point(897, 386));  //X
            XBoxButtonPoints.Add(new Point(970, 310));  //Y
        }
        /// <summary>
        /// FunctionListComboboxes Listesindeki Comboboxları Tek Tek Dolaşıp İçlerine Seçilen Moda Göre Fonksiyonların İsimlerini Atayan Fonksiyon.
        /// </summary>
        /// <param name="bothFunctionsList"></param>
        /// <returns></returns>
        public bool SetFunctionLists()
        {
            CommonMethods.FunctionMode FunctionMode = CommonMethods.FunctionMode.NoMode;
            if (functionsComboBox.SelectedItem != null)
            {
                if (functionsComboBox.SelectedIndex == CommonMethods.GetModeIndex(CommonMethods.FunctionMode.GimbalMode))
                {
                    FunctionMode = CommonMethods.FunctionMode.GimbalMode;
                    foreach (ComboBox item in functionsListComboboxes)
                    {

                        item.ItemsSource = null;
                        item.ItemsSource = gimbalFunctions.FunctionList;
                        item.DisplayMemberPath = "Method.Name";
                    }
                }
                else if (functionsComboBox.SelectedIndex == CommonMethods.GetModeIndex(CommonMethods.FunctionMode.IhaMode))
                {
                    FunctionMode = CommonMethods.FunctionMode.IhaMode;
                    foreach (ComboBox item in functionsListComboboxes)
                    {

                        item.ItemsSource = null;
                        item.ItemsSource = ihaFunctions.FunctionList;
                        item.DisplayMemberPath = "Method.Name";
                    }
                }
                else if (functionsComboBox.SelectedIndex == CommonMethods.GetModeIndex(CommonMethods.FunctionMode.AllMode))
                {
                    bothFunctionsList.Clear();
                    FunctionMode = CommonMethods.FunctionMode.AllMode;
                    //Ekleme Sırasını Bozmayınız!!!
                    foreach (var func in gimbalFunctions.FunctionList)
                    {
                        bothFunctionsList.Add(func);
                    }
                    foreach (var func in ihaFunctions.FunctionList)
                    {
                        bothFunctionsList.Add(func);
                    }
                    foreach (ComboBox item in functionsListComboboxes)
                    {
                        item.ItemsSource = null;
                        item.ItemsSource = bothFunctionsList;
                        item.DisplayMemberPath = "Method.Name";
                    }
                }
                if (CommonMethods.KUMANDA_TIPI.XBOX_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick))
                {
                    JoystickValuesPage.XBoxControllerClass.FunctionMode = FunctionMode;
                }
                if (CommonMethods.KUMANDA_TIPI.EXTREME_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick))
                {
                    JoystickValuesPage.ExtremeControllerClass.FunctionMode = FunctionMode;
                }
                return true;
            }
            else
            {
                MessageBox.Show("Lütfen Listelemek İçin Bir Mod Seçiniz.!"); return false;
            }
        }
        /// <summary>
        /// Seçilen Moda Göre Comboboxlara Fonksiyon İsimleri yükler.
        /// </summary>
        public void ListFunctionsButton_Click(object sender, RoutedEventArgs e)
        {
            if (listFunctionsButton.Opacity == 0.3)
            {
                MessageBox.Show(
    "Lütfen Farklı Moda Geçebilmek İçin Fonksiyon Atamalarınızı Resetleyiniz.",
    "Uyarı",
    MessageBoxButton.OK,
    MessageBoxImage.Warning
);
                return;
            }
            SetFunctionLists();
            modeIndex = CommonMethods.getMode(functionsComboBox.SelectedIndex);
        }
        /// <summary>
        /// XBox İçin Basılı Butonu Tespit Edip İndex Numarasını Döndürür.
        /// </summary>
        /// <param name="buttons">Controllerdam Alınır.</param>
        /// <returns>Basılı Buton İndexi</returns>
        private static int GetPressedButtonsXBox(GamepadButtonFlags buttons)
        {

            if ((buttons & GamepadButtonFlags.DPadUp) != 0) return 0;
            if ((buttons & GamepadButtonFlags.DPadLeft) != 0) return 1;
            if ((buttons & GamepadButtonFlags.DPadRight) != 0) return 2;
            if ((buttons & GamepadButtonFlags.DPadDown) != 0) return 3;
            if ((buttons & GamepadButtonFlags.Start) != 0) return 4;
            if ((buttons & GamepadButtonFlags.Back) != 0) return 5;
            if ((buttons & GamepadButtonFlags.LeftThumb) != 0) return 6;
            if ((buttons & GamepadButtonFlags.RightThumb) != 0) return 7;
            if ((buttons & GamepadButtonFlags.LeftShoulder) != 0) return 8;
            if ((buttons & GamepadButtonFlags.RightShoulder) != 0) return 9;
            if ((buttons & GamepadButtonFlags.A) != 0) return 10;
            if ((buttons & GamepadButtonFlags.B) != 0) return 11;
            if ((buttons & GamepadButtonFlags.X) != 0) return 12;
            if ((buttons & GamepadButtonFlags.Y) != 0) return 13;

            return -1;
        }
        /// <summary>
        /// İndex İle Kontrolün Yapılabilmesi İçin İlgili Companentin Name'ine Göre İndex'ini Gönderir.
        /// </summary>
        /// <param name="name">İlgili XML Item Name'i</param>
        /// <returns>Name Stringinde "_" den sonra gelen ilk Rakam</returns>
        public int SplitValue(string name)
        {
            try
            {
                return int.Parse(name.Split('_')[1]) - 1;

            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                return -1;
            }
        }
        public void ShowXBoxValues(Point point)
        {
            int XWidth;
            int YHeight;
            var state = controller.GetState();
            if (state.Gamepad.LeftThumbX != 0 && state.Gamepad.LeftThumbY != 0)//295-380 merkez noktası
            {
                XWidth = JoystickValuesPage.ValuesUserControl.Map(state.Gamepad.LeftThumbX, -32767, 32767, 220, 370);
                YHeight = JoystickValuesPage.ValuesUserControl.Map(state.Gamepad.LeftThumbY, 32767, -32767, 305, 455);
                JoystickValuesPage.StartAnimation(new Point(XWidth, YHeight));
            }
            else if (state.Gamepad.RightThumbX != 0 && state.Gamepad.RightThumbY != 0)//817-555 merkez noktası
            {
                XWidth = JoystickValuesPage.ValuesUserControl.Map(state.Gamepad.RightThumbX, -32767, 32767, 745, 895);
                YHeight = JoystickValuesPage.ValuesUserControl.Map(state.Gamepad.RightThumbY, 32767, -32767, 480, 630);
                JoystickValuesPage.StartAnimation(new Point(XWidth, YHeight));
            }
            else if (point.X > 0)
            {
                JoystickValuesPage.StartAnimation(point);
            }

        }
        /// <summary>
        /// JoystickValuesPage Deki async ReadJoystickButtons() Methodundan Belli Aralıklarla Çağırılan, Basılı Butona GÖre Fonksiyon Çalıştıran Method.
        /// </summary>
        public void CheckButtonStates()
        {
            if (CommonMethods.KUMANDA_TIPI.XBOX_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick))
            {
                ShowXBoxValues(new Point(-100, -100));//left-right-thumblar için
                foreach (FunctionRowController usercontrol in RowControlUserList)
                {
                    int index = SplitValue(usercontrol.Name);
                    var buttons = controller.GetState().Gamepad.Buttons;
                    if (GetPressedButtonsXBox(buttons) == index)
                    {
                        if (JoystickValuesPage.Tabs.SelectedIndex == 0)
                        {
                            usercontrol.Label.Foreground = new SolidColorBrush(Colors.Green); return;
                        }
                        else if (JoystickValuesPage.XBoxControllerClass.FunctionList[index] != null && JoystickValuesPage.XBoxControllerClass.FunctionList[index].FunctionIndex != null && JoystickValuesPage.Tabs.SelectedIndex != 0)
                        {
                            InvokeFunction(JoystickValuesPage.XBoxControllerClass.FunctionList[index], JoystickValuesPage.XBoxControllerClass.FunctionMode);
                        }
                        ShowXBoxValues(XBoxButtonPoints[index]);
                    }
                }
            }
            else if (CommonMethods.KUMANDA_TIPI.EXTREME_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick))
            {
                foreach (FunctionRowController usercontrol in RowControlUserList)
                {
                    try
                    {
                        var state = extremeJoystick.GetCurrentState();
                        int index = SplitValue(usercontrol.Name);
                        if (state.Buttons[index] is true)
                        {
                            if (JoystickValuesPage.Tabs.SelectedIndex == 0)
                            {
                                usercontrol.Label.Foreground = new SolidColorBrush(Colors.Green); return;
                            }
                            if (JoystickValuesPage.ExtremeControllerClass.FunctionList[index] != null && JoystickValuesPage.ExtremeControllerClass.FunctionList[index].FunctionIndex != null && JoystickValuesPage.Tabs.SelectedIndex != 0)
                            {
                                InvokeFunction(JoystickValuesPage.ExtremeControllerClass.FunctionList[index], JoystickValuesPage.ExtremeControllerClass.FunctionMode);
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        MessageBox.Show(e.Message);
                    }

                }
            }
        }
        /// <summary>
        /// Progress Barların Sürekli Duruma Göre Value Değeri Değişmesi İçin Kullanılan Method.
        /// </summary>
        public void ClearAllLabels()
        {
            var Color = new SolidColorBrush(Colors.White);
            r_1.Label.Foreground = Color;
            r_2.Label.Foreground = Color;
            r_3.Label.Foreground = Color;
            r_4.Label.Foreground = Color;
            r_5.Label.Foreground = Color;
            r_6.Label.Foreground = Color;
            r_7.Label.Foreground = Color;
            r_8.Label.Foreground = Color;
            r_9.Label.Foreground = Color;
            r_10.Label.Foreground = Color;
            r_11.Label.Foreground = Color;
            r_12.Label.Foreground = Color;
            r_13.Label.Foreground = Color;
            r_14.Label.Foreground = Color;

        }
        /// <summary>
        /// Kontrolcü FuncTionListe Atama Yapılan Fonksiyonlar Ve Modu Kaydedilir. Artık GoMode Özelliğini Kullanabiliriz.
        /// </summary>
        public void AssignFunctions()
        {
            modeIndex = CommonMethods.getMode(functionsComboBox.SelectedIndex);
            if (modeIndex is not CommonMethods.FunctionMode.NoMode)
            {
                listFunctionsButton.Opacity = 0.3;
                if (CommonMethods.KUMANDA_TIPI.XBOX_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick))
                {
                    JoystickValuesPage.XBoxControllerClass.FunctionMode = modeIndex;
                    foreach (FunctionRowController usercontrol in RowControlUserList)
                    {
                        int indx = SplitValue(usercontrol.Name);
                        if (usercontrol.ComboBox.SelectedIndex != -1)
                        {
                            JoystickValuesPage.XBoxControllerClass.FunctionList[indx].FunctionIndex = (usercontrol.ComboBox.SelectedIndex);
                            JoystickValuesPage.XBoxControllerClass.FunctionList[indx].VibrationState = (usercontrol.CheckBox.IsChecked == true ? true : false);
                            detectErrors.Content = $"Fonksiyon Atama Başarılı: {usercontrol.Label.Content} => {usercontrol.ComboBox.Text}";
                        }
                    }
                }
                else if (CommonMethods.KUMANDA_TIPI.EXTREME_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick))//extreme
                {
                    JoystickValuesPage.ExtremeControllerClass.FunctionMode = modeIndex;

                    foreach (FunctionRowController usercontrol in RowControlUserList)
                    {
                        int indx = SplitValue(usercontrol.Name);
                        if (usercontrol.ComboBox.SelectedIndex != -1)
                        {
                            JoystickValuesPage.ExtremeControllerClass.FunctionList[indx].FunctionIndex = (usercontrol.ComboBox.SelectedIndex);
                            detectErrors.Content = $"Fonksiyon Atama Başarılı:  Buton-{indx + 1}=>{usercontrol.ComboBox.Text}";
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Lütfen Önce Fonksiyonları Listeleyiniz!");
            }
        }
        /// <summary>
        /// gimbal/iha/all moda göre fonksiyonları İndex Numarasına Göre Çalıştıran Method.
        /// </summary>
        /// <param name="functionIndexes"></param>
        public void InvokeFunction(ButtonState functionIndexes, CommonMethods.FunctionMode functionMode)
        {
            if (functionMode == CommonMethods.FunctionMode.GimbalMode)
            {
                var selectedFunction = gimbalFunctions.FunctionList[(int)functionIndexes.FunctionIndex] as Func<int, string>;
                if (selectedFunction != null)
                {
                    JoystickValuesPage.FunctionWorkingGimbal.Content = ($"{selectedFunction.Invoke(1)} Çalıştı.");
                }
                else
                {
                    MessageBox.Show("Hata: Gimbal Fonksiyonu Atanamadı: ");
                }
            }
            else if (functionMode == CommonMethods.FunctionMode.IhaMode)
            {
                var selectedFunction = ihaFunctions.FunctionList[(int)functionIndexes.FunctionIndex] as Func<int, string>;
                if (selectedFunction != null)
                {
                    JoystickValuesPage.FunctionWorkingIha.Content = ($"{selectedFunction.Invoke(1)} Çalıştı.");

                }
                else
                {
                    MessageBox.Show("Hata: Iha Fonksiyonu Atanamadı: ");
                }

            }
            else if (functionMode == CommonMethods.FunctionMode.AllMode)
            {
                var selectedFunction = bothFunctionsList[(int)functionIndexes.FunctionIndex] as Func<int, string>;
                if (selectedFunction != null)
                {
                    JoystickValuesPage.FunctionWorkingAll.Content = ($"{selectedFunction.Invoke(1)} Çalıştı.");
                }
                else
                {
                    MessageBox.Show("Hata: BOTH Fonksiyonu Atanamadı: ");
                }
            }
            if (functionIndexes.VibrationState == CommonMethods.VibrationON)
            {
                StartVibration(1);
                return;
            }
        }
        /// <summary>
        /// Kontrolcüdeki Tanımlı FOnksiyonları Sıfırlayan Method.
        /// </summary>
        public void ResetFunctionLists()
        {
            listFunctionsButton.Opacity = 1;
            if (CommonMethods.KUMANDA_TIPI.XBOX_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick))
            {
                JoystickValuesPage.XBoxControllerClass.FunctionMode = CommonMethods.FunctionMode.NoMode;
                foreach (FunctionRowController usercontrol in RowControlUserList)
                {
                    usercontrol.CheckBox.IsChecked = false;
                }
                JoystickValuesPage.XBoxControllerClass.FunctionList.Clear();
                CommonMethods.AddButtonsForFunctions(JoystickValuesPage.XBoxControllerClass, JoystickValuesPage.ExtremeControllerClass, controller, extremeJoystick);
            }
            else if (CommonMethods.KUMANDA_TIPI.EXTREME_KUMANDA == CommonMethods.WhichJoystick(controller, extremeJoystick))
            {
                JoystickValuesPage.ExtremeControllerClass.FunctionMode = CommonMethods.FunctionMode.NoMode;
                JoystickValuesPage.ExtremeControllerClass.FunctionList.Clear();
                CommonMethods.AddButtonsForFunctions(JoystickValuesPage.XBoxControllerClass, JoystickValuesPage.ExtremeControllerClass, controller, extremeJoystick);
            }
            detectErrors.Content = "Resetleme İşlemi Başarıyla Gerçekleşti!";

            foreach (ComboBox item in functionsListComboboxes)
            {
                item.ItemsSource = null;
            }

            functionsComboBox.SelectedIndex = -1;
        }

    }
}
