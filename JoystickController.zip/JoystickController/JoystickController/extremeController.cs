﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Xml.Linq;

namespace JoystickController
{
    public class extremeController : parentExtreme
    {

        public  uint xValue { get { return Map(xValue, 0, 65535, MinX, MinY); } set { } }
        public  uint yValue { get; set; }
        public  uint zValue { get; set; }
        public  uint hatSwitch { get; set; }
        public  uint throttle { get; set; }
        public  bool[] buttons = new bool[12] { false, false, false, false, false, false, false, false, false, false, false, false };
        public uint Map(uint value, uint oldMin, uint oldMax, uint newMin, uint newMax)
        {
            return (uint)((value - oldMin) * (newMax - newMin) / (oldMax - oldMin) + newMin);
        }
         public void setDefaultValuesForExtreme()
        {
           xValue = 0; yValue = 0; zValue = 0; hatSwitch = 0; throttle = 0; Array.Fill(buttons, false);
        }
        public  override string ToString()
        {
            return base.ToString()+ "Child\n";
        }
    }
}
