﻿using SharpDX.DirectInput; // DirectInput  
using SharpDX.XInput; // XInput  
using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace JoystickController
{
    public partial class MainWindow : Window
    {
        private DirectInput directInput;
        private DispatcherTimer timer;
        private bool isConnected = false;
        private string nameXbox = "Xbox Joystick 1";
        private string nameExtreme = "Extreme 3D pro";
        private HashSet<string> currentJoysticks;//Listede Birden Fazla Aynı İsim Olmaması Gerektiği İçin HashSet Kullanıldı.
        public MainWindow()
        {
            InitializeComponent();
            directInput = new DirectInput();
            currentJoysticks = new HashSet<string>();
            LoadJoysticks();
            timer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(1)
            };
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        /// <summary>
        /// Joystick Values Page'e Geçiş Yapılan Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string? selectedJoystick = OptionsComboBox.SelectedItem?.ToString();
            if (string.IsNullOrEmpty(selectedJoystick))
            {
                MessageBox.Show("Lütfen bir joystick seçin.");
            }
            else
            {
                JoystickValuesPage valuesPage = new JoystickValuesPage(selectedJoystick);
                valuesPage.Show();
                timer.Stop();
                timer = null;
                directInput.Dispose();
                this.Close();
            }
        }

        /// <summary>
        /// Joystickleri Yükler
        /// </summary>
        private void LoadJoysticks()
        {
            var previousSelectedIndex = OptionsComboBox.SelectedIndex;
            var devices = directInput.GetDevices(SharpDX.DirectInput.DeviceType.Joystick, DeviceEnumerationFlags.AllDevices);
            HashSet<string> newJoysticks = new HashSet<string>();
            foreach (var device in devices)
            {

                newJoysticks.Add(device.InstanceName);
            }

            for (int i = 0; i < 4; i++)
            {
                var controller = new Controller((UserIndex)i);
                if (controller.IsConnected)
                {
                    newJoysticks.Add($"Xbox Joystick {i + 1}");
                }
            }

            if (!currentJoysticks.SetEquals(newJoysticks))
            {
                currentJoysticks = newJoysticks;
                OptionsComboBox.ItemsSource = newJoysticks;
                if (OptionsComboBox.Items.Count == 0 && !isConnected)
                {
                    isConnected = true;
                    MessageBox.Show("Bağlı joystick bulunamadı.");
                }
            }

            if (previousSelectedIndex >= 0 && previousSelectedIndex < OptionsComboBox.Items.Count)
            {
                OptionsComboBox.SelectedIndex = previousSelectedIndex;
            }
            else
            {
                OptionsComboBox.SelectedIndex = -1;
            }
        }

        /// <summary>
        /// 1 Saniyede Bir Listeyi Yeniler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Timer_Tick(object sender, EventArgs e)
        {
            LoadJoysticks(); // Joystickleri güncelle
        }

        private void MyComboBox_SelectionChanged(object sender, EventArgs e)
        {
            if (OptionsComboBox == null)
            {
                return;
            }

            var selectedJoystick = OptionsComboBox.SelectedItem?.ToString();
            if (string.IsNullOrEmpty(selectedJoystick))
            {
                return;
            }

            // Seçilen joystick ile ilgili işlemler
            videoPlayer.Stop();
            videoPlayer1.Stop();
            if (selectedJoystick == nameXbox)
            {
                label.Content = "";
                OptionsComboBox.Opacity = 0.4;
                ActionButton.Opacity = 0.4;
                imageBaykar.Opacity = 0;
                videoPlayer1.Position = TimeSpan.Zero;
                videoPlayer.Opacity = 0;
                videoPlayer1.Opacity = 1;
                videoPlayer1.Play();
            }
            else if (selectedJoystick == nameExtreme)
            {
                label.Content = "";
                OptionsComboBox.Opacity = 0.4;
                ActionButton.Opacity = 0.4;
                imageBaykar.Opacity = 0;
                videoPlayer.Position = TimeSpan.Zero;
                videoPlayer1.Opacity = 0;
                videoPlayer.Opacity = 1;
                videoPlayer.Play();
            }
            else
            {
                imageBaykar.Source = new BitmapImage(new Uri("/Photos/baykar.png"));
            }
        }

        private void ActionButton_MouseEnter(object sender, MouseEventArgs e)
        {
            ActionButton.Opacity = 0.3;
        }

        private void ActionButton_MouseLeave(object sender, MouseEventArgs e)
        {
            ActionButton.Opacity = 1.0; // 1.0 yaparak eski haline döndür
        }
    }
}
