﻿using System.Windows.Controls;

namespace JoystickController.User_Controller
{
    /// <summary>
    /// FunctionSettings.xaml etkileşim mantığı
    /// </summary>
    public partial class FunctionSettings : UserControl
    {
        public FunctionSettings()
        {
            InitializeComponent();
        }
    }
}
