﻿using JoystickController.Binding_Classes;
using JoystickController.Kumanda_Kontrolculeri;
using SharpDX.DirectInput;
using SharpDX.XInput;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;

namespace JoystickController.User_Controller
{
    /// <summary>
    ///Değer Listeleme İçin Kullanılmaktadır
    /// </summary>
    public partial class Values : UserControl
    {
        ObservableCollection<InputState> inputValues = [];
        private Controller controller;
#pragma warning disable CS0169 // 'Values.directInput' alanı hiçbir zaman kullanılmaz
        private DirectInput directInput;
#pragma warning restore CS0169 // 'Values.directInput' alanı hiçbir zaman kullanılmaz
        private Joystick extremeJoystick;
#pragma warning disable CS8618 // Null atanamaz alan, oluşturucudan çıkış yaparken null olmayan bir değer içermelidir. Alanı null atanabilir olarak bildirmeyi düşünün.
#pragma warning disable CS8618 // Null atanamaz alan, oluşturucudan çıkış yaparken null olmayan bir değer içermelidir. Alanı null atanabilir olarak bildirmeyi düşünün.
#pragma warning disable CS8618 // Null atanamaz alan, oluşturucudan çıkış yaparken null olmayan bir değer içermelidir. Alanı null atanabilir olarak bildirmeyi düşünün.
        public Values()
#pragma warning restore CS8618 // Null atanamaz alan, oluşturucudan çıkış yaparken null olmayan bir değer içermelidir. Alanı null atanabilir olarak bildirmeyi düşünün.
#pragma warning restore CS8618 // Null atanamaz alan, oluşturucudan çıkış yaparken null olmayan bir değer içermelidir. Alanı null atanabilir olarak bildirmeyi düşünün.
#pragma warning restore CS8618 // Null atanamaz alan, oluşturucudan çıkış yaparken null olmayan bir değer içermelidir. Alanı null atanabilir olarak bildirmeyi düşünün.
        {
            InitializeComponent();
            ButtonValuesList.ItemsSource = inputValues;
        }
        public enum KUMANDA_TIPI
        {
            XBOX_KUMANDA = 1,
            EXTREME_KUMANDA = 2,
            DEFAULT = 3
        }
        public void setControllerForXbox(int index)
        {
            controller = new Controller((UserIndex)index);
        }
        public void setControllerForExtreme(Joystick joystick)
        {
            extremeJoystick = joystick;
        }
        private async void Vibration_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(rightVib.Text, out int valueR) && int.TryParse(leftVib.Text, out int valueL))
            {
                SetVibration(valueL, valueR);
                await Task.Delay(1000);
                SetVibration(0, 0);
            }
            else
            {
                VibrationErrorLabel.Content = "lütfen geçerli bir değer giriniz!";
            }
        }
        public void SetVibration(int left, int right)
        {
            if (controller != null)
            {
                if (left < 11 && left >= 0 && right < 11 && right >= 0)
                {
                    var vibration = new SharpDX.XInput.Vibration
                    {
                        LeftMotorSpeed = (ushort)((left) * 6553.5),
                        RightMotorSpeed = (ushort)((right) * 6553.5)
                    };

                    controller.SetVibration(vibration);
                }
                else
                {
                    VibrationErrorLabel.Content = "lütfen geçerli bir aralık giriniz!";

                }
            }
            else
            {
                MessageBox.Show("Error! Vibrasyon için Kontrolcü bağlı değil.");
            }
        }
        public async void StartVibration(int zaman_sn_s32)
        {
            SetVibration(10, 10);

            await Task.Delay(zaman_sn_s32 * 1000);

            SetVibration(0, 0);
        }
        public KUMANDA_TIPI WhichJoystick()
        {
            if (controller != null && controller.IsConnected)
            {
                return KUMANDA_TIPI.XBOX_KUMANDA; // xBox kontrolcüsü bağlı
            }
            else if (extremeJoystick != null)
            {
                return KUMANDA_TIPI.EXTREME_KUMANDA; // extreme joystick bağlı
            }
            return KUMANDA_TIPI.DEFAULT;

        }
        public void CheckDPadButtons(controlXBox cXBox)
        {
            try
            {
                var state = controller.GetState();
                GamepadButtonFlags buttons = state.Gamepad.Buttons;
                if ((buttons & GamepadButtonFlags.DPadUp) != 0 && cXBox.DPadY <= cXBox.DPadMax - cXBox.YStepSize)
                {
                    cXBox.DPadY += cXBox.YStepSize;
                }
                if ((buttons & GamepadButtonFlags.DPadDown) != 0 && cXBox.DPadY >= cXBox.DPadMin + cXBox.YStepSize)
                {
                    cXBox.DPadY -= cXBox.YStepSize;
                }
                if ((buttons & GamepadButtonFlags.DPadRight) != 0 && cXBox.DPadX <= cXBox.DPadMax - cXBox.XStepSize)
                {
                    cXBox.DPadX += cXBox.XStepSize;
                }
                if ((buttons & GamepadButtonFlags.DPadLeft) != 0 && cXBox.DPadX >= cXBox.DPadMin + cXBox.XStepSize)
                {
                    cXBox.DPadX -= cXBox.XStepSize;
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }

        }
        private void AddButtonStatesXBox(ICollection<InputState> inputValues, GamepadButtonFlags buttons, controlXBox cXBox)
        {
            CheckDPadButtons(cXBox);
            inputValues.Add(new InputState { Input = "D-Pad Up", Value = (buttons & GamepadButtonFlags.DPadUp) != 0 ? "Pressed" : "Released", NewValue = cXBox.DPadY.ToString(), Min = cXBox.DPadMin.ToString(), Max = cXBox.DPadMax.ToString() });
            inputValues.Add(new InputState { Input = "D-Pad Left", Value = (buttons & GamepadButtonFlags.DPadLeft) != 0 ? "Pressed" : "Released", NewValue = cXBox.DPadX.ToString(), Min = cXBox.DPadMin.ToString(), Max = cXBox.DPadMax.ToString() });
            inputValues.Add(new InputState { Input = "D-Pad Right", Value = (buttons & GamepadButtonFlags.DPadRight) != 0 ? "Pressed" : "Released", NewValue = (buttons & GamepadButtonFlags.DPadRight) != 0 ? "1" : "0", Min = "0", Max = "1" });
            inputValues.Add(new InputState { Input = "D-Pad Down", Value = (buttons & GamepadButtonFlags.DPadDown) != 0 ? "Pressed" : "Released", NewValue = (buttons & GamepadButtonFlags.DPadDown) != 0 ? "1" : "0", Min = "0", Max = "1" });
            inputValues.Add(new InputState { Input = "Start", Value = (buttons & GamepadButtonFlags.Start) != 0 ? "Pressed" : "Released", NewValue = (buttons & GamepadButtonFlags.Start) != 0 ? "1" : "0", Min = "0", Max = "1" });
            inputValues.Add(new InputState { Input = "Back", Value = (buttons & GamepadButtonFlags.Back) != 0 ? "Pressed" : "Released", NewValue = (buttons & GamepadButtonFlags.Back) != 0 ? "1" : "0", Min = "0", Max = "1" });
            inputValues.Add(new InputState { Input = "Left Thumb", Value = (buttons & GamepadButtonFlags.LeftThumb) != 0 ? "Pressed" : "Released", NewValue = (buttons & GamepadButtonFlags.LeftThumb) != 0 ? "1" : "0", Min = "0", Max = "1" });
            inputValues.Add(new InputState { Input = "Right Thumb", Value = (buttons & GamepadButtonFlags.RightThumb) != 0 ? "Pressed" : "Released", NewValue = (buttons & GamepadButtonFlags.RightThumb) != 0 ? "1" : "0", Min = "0", Max = "1" });
            inputValues.Add(new InputState { Input = "Left Shoulder", Value = (buttons & GamepadButtonFlags.LeftShoulder) != 0 ? "Pressed" : "Released", NewValue = (buttons & GamepadButtonFlags.LeftShoulder) != 0 ? "1" : "0", Min = "0", Max = "1" });
            inputValues.Add(new InputState { Input = "Right Shoulder", Value = (buttons & GamepadButtonFlags.RightShoulder) != 0 ? "Pressed" : "Released", NewValue = (buttons & GamepadButtonFlags.RightShoulder) != 0 ? "1" : "0", Min = "0", Max = "1" });
            inputValues.Add(new InputState { Input = "A", Value = (buttons & GamepadButtonFlags.A) != 0 ? "Pressed" : "Released", NewValue = (buttons & GamepadButtonFlags.A) != 0 ? "1" : "0", Min = "0", Max = "1" });
            inputValues.Add(new InputState { Input = "B", Value = (buttons & GamepadButtonFlags.B) != 0 ? "Pressed" : "Released", NewValue = (buttons & GamepadButtonFlags.B) != 0 ? "1" : "0", Min = "0", Max = "1" });
            inputValues.Add(new InputState { Input = "X", Value = (buttons & GamepadButtonFlags.X) != 0 ? "Pressed" : "Released", NewValue = (buttons & GamepadButtonFlags.X) != 0 ? "1" : "0", Min = "0", Max = "1" });
            inputValues.Add(new InputState { Input = "Y", Value = (buttons & GamepadButtonFlags.Y) != 0 ? "Pressed" : "Released", NewValue = (buttons & GamepadButtonFlags.Y) != 0 ? "1" : "0", Min = "0", Max = "1" });
        }
        public void ShowJoystickValues(controlXBox cXBox, controlExtreme cExtreme)
        {
            inputValues.Clear();
            if (KUMANDA_TIPI.XBOX_KUMANDA == WhichJoystick())
            {
                if (controller == null)
                {
                    ControllerTypeLabel.Content = "Joystick bağlantısı yok !!!";
                    return;
                }
                var state = controller.GetState();

                inputValues.Add(new InputState
                {
                    Input = "Left Thumbstick X",
                    Value = state.Gamepad.LeftThumbX.ToString(),
                    NewValue = SetLimitsXBox(state.Gamepad.LeftThumbX, (int)cXBox.MinLeftThumbstickX, cXBox.TrimLeftThumbstickX, cXBox.MaxLeftThumbstickX, false, cXBox.ReverseMinLeftThumbstickX),
                    Min = cXBox.MinLeftThumbstickX.ToString(),
                    Max = cXBox.MaxLeftThumbstickX.ToString()
                });
                inputValues.Add(new InputState
                {
                    Input = "Left Thumbstick Y",
                    Value = state.Gamepad.LeftThumbY.ToString(),
                    NewValue = SetLimitsXBox(state.Gamepad.LeftThumbY, (int)cXBox.MinLeftThumbstickY, cXBox.TrimLeftThumbstickY, cXBox.MaxLeftThumbstickY, false, cXBox.ReverseMinLeftThumbstickY),
                    Min = cXBox.MinLeftThumbstickY.ToString(),
                    Max = cXBox.MaxLeftThumbstickY.ToString()
                });
                inputValues.Add(new InputState
                {
                    Input = "Right Thumbstick X",
                    Value = state.Gamepad.RightThumbX.ToString(),
                    NewValue = SetLimitsXBox(state.Gamepad.RightThumbX, (int)cXBox.MinRightThumbstickX, cXBox.TrimRightThumbstickX, cXBox.MaxRightThumbstickX, false, cXBox.ReverseMinRightThumbstickX),
                    Min = cXBox.MinRightThumbstickX.ToString(),
                    Max = cXBox.MaxRightThumbstickX.ToString()
                });
                inputValues.Add(new InputState
                {
                    Input = "Right Thumbstick Y",
                    Value = state.Gamepad.RightThumbY.ToString(),
                    NewValue = SetLimitsXBox(state.Gamepad.RightThumbY, (int)cXBox.MinRightThumbstickY, cXBox.TrimRightThumbstickY, cXBox.MaxRightThumbstickY, false, cXBox.ReverseMinRightThumbstickY),
                    Min = cXBox.MinRightThumbstickY.ToString(),
                    Max = cXBox.MaxRightThumbstickY.ToString()
                });
                inputValues.Add(new InputState
                {
                    Input = "Left Trigger",
                    Value = state.Gamepad.LeftTrigger.ToString(),
                    NewValue = SetLimitsXBox(state.Gamepad.LeftTrigger, (int)cXBox.MinLeftTrigger, 1, cXBox.MaxLeftTrigger, true, cXBox.reverseMinLeftTrigger),
                    Min = cXBox.MinLeftTrigger.ToString(),
                    Max = cXBox.MaxLeftTrigger.ToString()
                });
                inputValues.Add(new InputState
                {
                    Input = "Right Trigger",
                    Value = state.Gamepad.RightTrigger.ToString(),
                    NewValue = SetLimitsXBox(state.Gamepad.RightTrigger, (int)cXBox.MinRightTrigger, 1, cXBox.MaxRightTrigger, true, cXBox.ReverseMinRightTrigger),
                    Min = cXBox.MinRightTrigger.ToString(),
                    Max = cXBox.MaxRightTrigger.ToString()
                });
                AddButtonStatesXBox(inputValues, state.Gamepad.Buttons, cXBox);

            }
            else if (KUMANDA_TIPI.EXTREME_KUMANDA == WhichJoystick())
            {
                if (extremeJoystick == null)
                {
                    ControllerTypeLabel.Content = "Joystick bağlantısı yok !!!";
                    return;
                }
                var state = extremeJoystick.GetCurrentState();

                inputValues.Add(new InputState { Input = "X Axis", Value = state.X.ToString(), NewValue = SetLimitsEx(state.X, cExtreme.MinX, cExtreme.TrimValueX, cExtreme.MaxX, "", false, cExtreme.ReverseX, cExtreme), Min = cExtreme.MinX.ToString(), Max = cExtreme.MaxX.ToString() });
                inputValues.Add(new InputState { Input = "Y Axis", Value = state.Y.ToString(), NewValue = SetLimitsEx(state.Y, cExtreme.MinY, cExtreme.TrimValueY, cExtreme.MaxY, "", false, cExtreme.ReverseY, cExtreme), Min = cExtreme.MinY.ToString(), Max = cExtreme.MaxY.ToString() });
                inputValues.Add(new InputState { Input = "Z Axis", Value = state.RotationZ.ToString(), NewValue = SetLimitsEx(state.RotationZ, cExtreme.MinZ, cExtreme.TrimValueZ, cExtreme.MaxZ, "", false, cExtreme.ReverseZ, cExtreme), Min = cExtreme.MinZ.ToString(), Max = cExtreme.MaxZ.ToString() });
                SetLimitsEx(state.PointOfViewControllers[0], cExtreme.MinHat, cExtreme.TrimValueHat, cExtreme.MaxHat, "X", false, cExtreme.ReverseHat, cExtreme);
                SetLimitsEx(state.PointOfViewControllers[0], cExtreme.MinHat, cExtreme.TrimValueHat, cExtreme.MaxHat, "Y", false, cExtreme.ReverseHat, cExtreme);
                inputValues.Add(new InputState { Input = "Hat Switch X", Value = state.PointOfViewControllers[0].ToString(), NewValue = cExtreme.XValueHat.ToString(), Min = cExtreme.MinHat.ToString(), Max = cExtreme.MaxHat.ToString() });
                inputValues.Add(new InputState { Input = "Hat Switch Y", Value = state.PointOfViewControllers[0].ToString(), NewValue = cExtreme.YValueHat.ToString(), Min = cExtreme.MinHat.ToString(), Max = cExtreme.MaxHat.ToString() });
                inputValues.Add(new InputState { Input = "Throttle", Value = state.Sliders[0].ToString(), NewValue = SetLimitsEx(state.Sliders[0], cExtreme.MinThrottle, 0, cExtreme.MaxThrottle, "", true, cExtreme.ReverseThrottle, cExtreme), Min = cExtreme.MinThrottle.ToString(), Max = cExtreme.MaxThrottle.ToString() });

                for (int i = 0; i <= 11; i++)
                {
                    if (i < state.Buttons.Length)
                    {
                        inputValues.Add(new InputState { Input = $"Button {i + 1}", Value = state.Buttons[i] ? "Pressed" : "Released", NewValue = state.Buttons[i] ? "1" : "0", Min = "0", Max = "1" });
                    }
                }
            }
        }
        public string SetLimitsXBox(int state, int min, uint trim, uint max, bool isTrigger, bool isReversed)
        {
            if (isTrigger)
            {
                if (isReversed)
                {
                    return Map(255 - state, 0, 255, (int)min, (int)max).ToString();
                }
                return Map(state, 0, 255, (int)min, (int)max).ToString();
            }
            else if (state <= -1000)
            {
                if (isReversed)
                {
                    return Map(state, -1000, -32767, (int)trim, (int)max).ToString();
                }
                return Map(state, -32767, -1000, (int)min, (int)trim).ToString();
            }
            else if (state >= 1000)
            {
                if (isReversed)
                {
                    return Map(state, 32767, 1000, (int)min, (int)trim).ToString();
                }
                return Map(state, 1000, 32767, (int)trim, (int)max).ToString();
            }
            return trim.ToString();
        }
        public string SetLimitsEx(int state, uint min, uint trim, uint max, string isHatSwitch, bool isThrottle, bool isReversed, controlExtreme cExtreme)
        {
            if (isThrottle)
            {
                if (isReversed)
                {
                    return Map(65535 - state, 0, 65535, (int)min, (int)max).ToString();
                }
                return Map(state, 0, 65535, (int)min, (int)max).ToString();

            }
            else if (isHatSwitch == "X" || isHatSwitch == "Y")
            {
                if (state == -1)
                {
                    if (isHatSwitch == "X") { return cExtreme.XValueHat.ToString(); }
                    else { return cExtreme.YValueHat.ToString(); }
                }

                // X için artış
                if (((state >= 4000 && state <= 5500) || (state > 8000 && state < 10000 || (state <= 14000 && state >= 13000))) && cExtreme.XValueHat <= cExtreme.MaxHat - cExtreme.XHatStepSize)
                {
                    cExtreme.XValueHat += cExtreme.XHatStepSize;
                    if (!cExtreme.Hat8AxisMode)
                    {
                        return "";
                    }
                }
                // X için azalış
                if (((state > 26000 && state < 28000) || (state <= 23000 && state >= 22000) || (state <= 32000 && state >= 31000)) && cExtreme.XValueHat >= cExtreme.MinHat + cExtreme.XHatStepSize)
                {
                    cExtreme.XValueHat -= cExtreme.XHatStepSize;
                    if (!cExtreme.Hat8AxisMode)
                    {
                        return "";
                    }
                }
                // Y için artış 
                if (((state >= 4000 && state <= 5000) || ((state >= 0 && state < 1000) || (state > 32000)) || (state <= 32000 && state >= 31000)) && (cExtreme.YValueHat <= cExtreme.MaxHat - cExtreme.YHatStepSize))
                {
                    cExtreme.YValueHat += cExtreme.YHatStepSize;
                    if (!cExtreme.Hat8AxisMode)
                    {
                        return "";
                    }
                }
                // Y için azalış
                if (((state > 17000 && state < 19000) || (state <= 14000 && state >= 13000) || (state <= 23000 && state >= 22000)) && (cExtreme.YValueHat >= cExtreme.MinHat + cExtreme.YHatStepSize))
                {
                    cExtreme.YValueHat -= cExtreme.YHatStepSize;
                    if (!cExtreme.Hat8AxisMode)
                    {
                        return "";
                    }
                }
            }

            else if (state < 32000)
            {
                if (isReversed)
                {
                    return Map(state, 32767, 0, (int)trim, (int)max).ToString();
                }
                return Map(state, 0, 32767, (int)min, (int)trim).ToString();
            }
            else if (state > 34000)
            {
                if (isReversed)
                {
                    return Map(state, 65535, 34000, (int)min, (int)trim).ToString();
                }
                return Map(state, 34000, 65535, (int)trim, (int)max).ToString();
            }
            return trim.ToString();
        }
        public int Map(int value, int oldMin, int oldMax, int newMin, int newMax)
        {
            return (int)((value - oldMin) * ((newMax) - (newMin)) / (oldMax - oldMin) + (newMin));
        }
    }
}
