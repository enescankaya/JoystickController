﻿using System.Windows.Controls;

namespace JoystickController.User_Controller
{
    /// <summary>
    /// LimitSettings.xaml etkileşim mantığı
    /// </summary>
    public partial class LimitSettings : UserControl
    {
        public LimitSettings()
        {
            InitializeComponent();
        }

    }
}
