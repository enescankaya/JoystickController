﻿
using System.Collections.ObjectModel;

namespace JoystickController.Function_Classes
{
    internal class RandomFunctionsGimball
    {
        // Fonksiyonları tutan bir liste
        public ObservableCollection<object> FunctionList { get; set; }
        public RandomFunctionsGimball()
        {
            // Listeyi oluşturuyoruz ve tüm Gimbal fonksiyonlarını ekliyoruz
            FunctionList = new ObservableCollection<object>
            {
                GimbalFunction1,
                GimbalFunction2,
                GimbalFunction3,
                GimbalFunction4,
                GimbalFunction5,
                GimbalFunction6,
                GimbalFunction7,
                GimbalFunction8,
                GimbalFunction9,
                GimbalFunction10,
                GimbalFunction11,
                GimbalFunction12,
                GimbalFunction13,
                GimbalFunction14,
                GimbalFunction15,
                GimbalFunction16,
                GimbalFunction17,
                GimbalFunction18,
                GimbalFunction19,
                GimbalDefaultFunction
            };
        }

        public string GimbalFunction1(int value)
        {
            return $"GimbalFunction1: {value}";
        }

        public string GimbalFunction2(int value)
        {
            return $"GimbalFunction2: {value}";
        }

        public string GimbalFunction3(int value)
        {
            return $"GimbalFunction3: {value}";
        }

        public string GimbalFunction4(int value)
        {
            return $"GimbalFunction4: {value}";
        }

        public string GimbalFunction5(int value)
        {
            return $"GimbalFunction5: {value}";
        }

        public string GimbalFunction6(int value)
        {
            return $"GimbalFunction6: {value}";
        }

        public string GimbalFunction7(int value)
        {
            return $"GimbalFunction7: {value}";
        }

        public string GimbalFunction8(int value)
        {
            return $"GimbalFunction8: {value}";
        }

        public string GimbalFunction9(int value)
        {
            return $"GimbalFunction9: {value}";
        }

        public string GimbalFunction10(int value)
        {
            return $"GimbalFunction10: {value}";
        }

        public string GimbalFunction11(int value)
        {
            return $"GimbalFunction11: {value}";
        }

        public string GimbalFunction12(int value)
        {
            return $"GimbalFunction12: {value}";
        }

        public string GimbalFunction13(int value)
        {
            return $"GimbalFunction13: {value}";
        }

        public string GimbalFunction14(int value)
        {
            return $"GimbalFunction14: {value}";
        }

        public string GimbalFunction15(int value)
        {
            return $"GimbalFunction15: {value}";
        }

        public string GimbalFunction16(int value)
        {
            return $"GimbalFunction16: {value}";
        }

        public string GimbalFunction17(int value)
        {
            return $"GimbalFunction17: {value}";
        }

        public string GimbalFunction18(int value)
        {
            return $"GimbalFunction18: {value}";
        }

        public string GimbalFunction19(int value)
        {
            return $"GimbalFunction19: {value}";
        }

        public string GimbalDefaultFunction(int value)
        {
            return $"GimbalDefaultFunction: {value}";
        }
    }
}
