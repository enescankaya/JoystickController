﻿using System.Collections.ObjectModel;

namespace JoystickController.Function_Classes
{
    internal class RandomFunctionsIha
    {
        public ObservableCollection<object> FunctionList { get; set; }

        public RandomFunctionsIha()
        {
            FunctionList = new ObservableCollection<object>
            {
                IhaFunction1,
                IhaFunction2,
                IhaFunction3,
                IhaFunction4,
                IhaFunction5,
                IhaFunction6,
                IhaFunction7,
                IhaFunction8,
                IhaFunction9,
                IhaFunction10,
                IhaFunction11,
                IhaFunction12,
                IhaFunction13,
                IhaFunction14,
                IhaFunction15,
                IhaFunction16,
                IhaFunction17,
                IhaFunction18,
                IhaFunction19,
                IhaDefaultFunction
            };
        }

        public string IhaFunction1(int value)
        {
            return $"IhaFunction1: {value}";
        }

        public string IhaFunction2(int value)
        {
            return $"IhaFunction2: {value}";
        }

        public string IhaFunction3(int value)
        {
            return $"IhaFunction3: {value}";
        }

        public string IhaFunction4(int value)
        {
            return $"IhaFunction4: {value}";
        }

        public string IhaFunction5(int value)
        {
            return $"IhaFunction5: {value}";
        }

        public string IhaFunction6(int value)
        {
            return $"IhaFunction6: {value}";
        }

        public string IhaFunction7(int value)
        {
            return $"IhaFunction7: {value}";
        }

        public string IhaFunction8(int value)
        {
            return $"IhaFunction8: {value}";
        }

        public string IhaFunction9(int value)
        {
            return $"IhaFunction9: {value}";
        }

        public string IhaFunction10(int value)
        {
            return $"IhaFunction10: {value}";
        }

        public string IhaFunction11(int value)
        {
            return $"IhaFunction11: {value}";
        }

        public string IhaFunction12(int value)
        {
            return $"IhaFunction12: {value}";
        }

        public string IhaFunction13(int value)
        {
            return $"IhaFunction13: {value}";
        }

        public string IhaFunction14(int value)
        {
            return $"IhaFunction14: {value}";
        }

        public string IhaFunction15(int value)
        {
            return $"IhaFunction15: {value}";
        }

        public string IhaFunction16(int value)
        {
            return $"IhaFunction16: {value}";
        }

        public string IhaFunction17(int value)
        {
            return $"IhaFunction17: {value}";
        }

        public string IhaFunction18(int value)
        {
            return $"IhaFunction18: {value}";
        }

        public string IhaFunction19(int value)
        {
            return $"IhaFunction19: {value}";
        }

        public string IhaDefaultFunction(int value)
        {
            return $"IhaDefaultFunction: {value}";
        }
    }
}
