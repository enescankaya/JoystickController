﻿using JoystickController.Interfaces;
using JoystickController.Joystick_Controllers;

namespace JoystickController.Kumanda_Kontrolculeri
{
    public class BaseController
    {
        /// <summary>
        /// Function İndex,Vibration
        /// Bu Listenin içerisinde Buton indexlerini tutan listeler var.
        /// </summary>
        public List<ButtonState>? FunctionList { get; set; } = new List<ButtonState>();
        public CommonMethods.FunctionMode FunctionMode { get; set; } = CommonMethods.FunctionMode.NoMode;
        public string FunctionModeName { get; set; }
        public string? PilotName { get; set; }
        public string? DateTime { get; set; }
        public uint MinThreshold { get; set; } = 500;
        public uint MaxThreshold { get; set; } = 1900;
    }
}
