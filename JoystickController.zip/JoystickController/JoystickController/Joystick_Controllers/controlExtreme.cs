﻿namespace JoystickController.Kumanda_Kontrolculeri
{
    public class controlExtreme : BaseController
    {
        public string ClassName { get; private set; } = "Extreme Controller";
        public uint MinX { get; set; } = 500;
        public bool ReverseX { get; set; } = false;
        public uint TrimValueX { get; set; } = 1500;
        public uint MaxX { get; set; } = 1900;
        public uint MinY { get; set; } = 500;
        public bool ReverseY { get; set; }
        public uint TrimValueY { get; set; } = 1500;
        public uint MaxY { get; set; } = 1900;
        public uint MinZ { get; set; } = 500;
        public uint TrimValueZ { get; set; } = 1500;
        public bool ReverseZ { get; set; } = false;
        public uint MaxZ { get; set; } = 1900;
        public uint MinHat { get; set; } = 0;
        public bool ReverseHat { get; set; } = false;
        public uint XValueHat { get; set; } = 0;
        public uint YValueHat { get; set; } = 0;
        public uint TrimValueHat { get; set; } = 0;
        public uint XHatStepSize { get; set; } = 1;
        public uint YHatStepSize { get; set; } = 1;
        public uint MaxHat { get; set; } = 100;
        public uint MinThrottle { get; set; } = 0;
        public bool ReverseThrottle { get; set; } = false;
        public uint MaxThrottle { get; set; } = 100;


    }
}
