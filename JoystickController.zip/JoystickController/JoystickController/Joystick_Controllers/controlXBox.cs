﻿namespace JoystickController.Kumanda_Kontrolculeri
{
    public class controlXBox : BaseController
    {
        public string className { get; private set; } = "XBox Controller";
        public uint DPadX { get; set; } = 0;
        public uint RightVibrationValue { get; set; } = 10;
        public uint LeftVibrationValue { get; set; } = 10;
        public uint DPadY { get; set; } = 0;
        public uint DPadMin { get; set; } = 0;
        public uint DPadMax { get; set; } = 100;
        public uint XStepSize { get; set; } = 1;
        public uint YStepSize { get; set; } = 1;
        public uint MinLeftThumbstickX { get; set; } = 500;
        public bool ReverseMinLeftThumbstickX { get; set; } = false;
        public uint MaxLeftThumbstickX { get; set; } = 1900;
        public uint TrimLeftThumbstickX { get; set; } = 1500;
        public uint MinLeftThumbstickY { get; set; } = 500;
        public bool ReverseMinLeftThumbstickY { get; set; } = false;
        public uint MaxLeftThumbstickY { get; set; } = 1900;
        public uint TrimLeftThumbstickY { get; set; } = 1500;
        public uint MinRightThumbstickX { get; set; } = 500;
        public bool ReverseMinRightThumbstickX { get; set; } = false;
        public uint MaxRightThumbstickX { get; set; } = 1900;
        public uint TrimRightThumbstickX { get; set; } = 1500;
        public uint MinRightThumbstickY { get; set; } = 500;
        public bool ReverseMinRightThumbstickY { get; set; } = false;
        public uint MaxRightThumbstickY { get; set; } = 1900;
        public uint TrimRightThumbstickY { get; set; } = 1500;
        public uint MinLeftTrigger { get; set; } = 500;
        public bool reverseMinLeftTrigger { get; set; } = false;
        public uint MaxLeftTrigger { get; set; } = 1900;
        public uint MinRightTrigger { get; set; } = 500;
        public bool ReverseMinRightTrigger { get; set; } = false;
        public uint MaxRightTrigger { get; set; } = 1900;

    }
}
