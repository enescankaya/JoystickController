﻿namespace JoystickController.Joystick_Controllers
{
    public class ButtonState
    {
        public int? FunctionIndex { get; set; }
        public bool VibrationState { get; set; } = false;
    }
}
