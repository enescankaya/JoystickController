﻿
using JoystickController.Interfaces;
using JoystickController.Kumanda_Kontrolculeri;
using JoystickController.User_Controllers;
using Microsoft.Win32;
using SharpDX.DirectInput;
using SharpDX.XInput;
using System.IO;
using System.Reflection.Metadata.Ecma335;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
namespace JoystickController
{
    /// <summary>
    /// Lütfem İndex Bazlı Ayarlamalarla Oynamayınız!. Tüm Sıralama Atama İşlemleri index bazında yapılıyor olup index numaralarının değiştirilmesi durumunda İşlevsiz Kalacaktır.
    /// </summary>
    public partial class JoystickValuesPage : Window
    {
        #region PARAMETERS
        private string joystickName;
        /// <summary>
        /// Extreme 3D Pro Class'ı
        /// </summary>
        public controlExtreme ExtremeControllerClass;
        /// <summary>
        /// XBox Kontrolcü Class'ı
        /// </summary>
        public controlXBox XBoxControllerClass;
        private bool IsContinuousMainAsync = true;
        private bool IsContinuousSecondAsync = false;
        private List<TabItem> tabs = [];
        /// <summary>
        /// StartReadingJoystickValues() async için delay time
        /// </summary>
        private const int MainAsyncDelayTime = 50;
        public bool isVisible = false;
        /// <summary>
        /// ReadJoystickButtons async için delay time
        /// </summary>
        private const int SecondAsyncDelayTime = 60;
        #endregion
        public JoystickValuesPage(string joystickName)
        {
            InitializeComponent();
            AddAllTabs();
            this.joystickName = joystickName;
            ValuesUserControl.ControllerTypeLabel.Text = $"KONTROLCÜ: {joystickName}";
            InitializeController(joystickName);
        }
        /// <summary>
        /// Kontrolcüleri Ayarlayıp Gerekli Ön Yüklemeleri Gerçekleştiren Ve Program Başında Sadece Bir Kez Çalışan Method
        /// </summary>
        /// <param name="joystickName">MainWİndow dan Gönderilen joystickName Parametresi Hangi Kontrolcünün Seçildiği Bilgisini Taşıyor. Buna Göre Methodlar ve Parametrelere Ayarlanıyor.</param>
        private void InitializeController(string joystickName)
        {
            if (joystickName.StartsWith("Xbox"))
            {
                XBoxControllerClass = new controlXBox();
                int index = int.Parse(joystickName.Substring(14, 1)) - 1;
                CommonMethods.controller = new Controller((UserIndex)index);
                ValuesUserControl.setControllerForXbox(index, this);
                LimitSettingsControl.setControllerForXbox(index, this);
                FunctionsSettingsControl.setControllerForXbox(index, this);
                ValuesListGroupBox.Header = "XBox Values";
            }
            else if (joystickName.StartsWith("Extreme"))
            {
                this.Height = 760;
                ExtremeControllerClass = new controlExtreme();
                CommonMethods.directInput = new DirectInput();
                ValuesListGroupBox.Header = "Extreme 3D PRO Values";
                foreach (var device in CommonMethods.directInput.GetDevices(SharpDX.DirectInput.DeviceType.Joystick, DeviceEnumerationFlags.AllDevices))
                {
                    if (device.InstanceName == joystickName)
                    {
                        CommonMethods.extremeJoystick = new Joystick(CommonMethods.directInput, device.InstanceGuid);
                        ValuesUserControl.setControllerForExtreme(CommonMethods.extremeJoystick, this);
                        LimitSettingsControl.setControllerForExtreme(CommonMethods.extremeJoystick, this);
                        FunctionsSettingsControl.setControllerForExtreme(CommonMethods.extremeJoystick, this);
                        CommonMethods.extremeJoystick.Acquire();
                        break;
                    }
                }
            }
            CommonMethods.AddButtonsForFunctions(XBoxControllerClass, ExtremeControllerClass, CommonMethods.controller, CommonMethods.extremeJoystick);
            showTab(settingsTab, CommonMethods.WhichJoystick(CommonMethods.controller, CommonMethods.extremeJoystick));
            LimitSettingsControl.FillPageForControllers();
        }
        /// <summary>
        /// MainAsyncDelayTime milisaniyede bir (İstere Göre Değiştirilebilir) Kontrolcü Verilerini ListView'e Aktaran,
        /// Bağlı Olan Kontrolcüye Göre Kontrolcü Buton Durumlarını Kontrol eden,
        /// Yapılan Değişiklikleri İlgili Kontrocü Classa Aktaran
        /// FunctionSettings UserControl de bulunan ProgressBarların Value Değerlerini Basılan Butona Göre Değiştiren Async Fonksiyon
        /// </summary>
        private async void StartReadingJoystickValues()
        {
            while (IsContinuousMainAsync)
            {
                FunctionsSettingsControl.ClearAllLabels();
                ValuesUserControl.ShowJoystickValues();
                FunctionsSettingsControl.CheckButtonStates();
                await Task.Delay(MainAsyncDelayTime);//ms
            }
        }
        /// <summary>
        /// Extreme Kontrolcü Seçildiğinde Gizlenmesi Gereken Öğeleri Ayarlayan Fonksiyon
        /// </summary>

        /// <summary>
        /// Farklı Kontrolcü Seçilmek İstendiğinde Gerekli Yapılandırmaları Yapan Event
        /// </summary>
        private void SelectAnotherJoystickButtonButton_Click(object sender, RoutedEventArgs e)
        {
            IsContinuousMainAsync = false;
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        /// <summary>
        /// FunctionSetting UserControlde ComboBoxlardan Seçilen Buton Ve Fonksiyonlara Göre Mevcut Konrolcüye Fonksiyon Atayan ButtonEven
        /// </summary>
        private void AssignFunctionsButton_Click(object sender, RoutedEventArgs e)
        {
            FunctionsSettingsControl.AssignFunctions();
        }
        /// <summary>
        /// Mevcut Kontrolcüde Tanımlı Fonksiyonları Resetleyen ButtonClickEvent
        /// </summary>
        private void ResetButton_Click(object sender, RoutedEventArgs e)
        {
            FunctionsSettingsControl.ResetFunctionLists();
        }
        /// <summary>
        /// İlgili Kontrolcü Classına Kaydedilmiş Ayarlamaları Json Formatta Serialize Eden(Kaydeden) ButtonClickEvent 
        /// </summary>
        private void SaveSettingsButton_Click(object sender, RoutedEventArgs e)
        {
            if (!isVisible)
            {
                LimitSettingsControl.PilotNameSection.Visibility = Visibility.Visible;
                LimitSettingsControl.pilotError.Content = "Enter Pilot Name";
                isVisible = true;
            }
            else
            {
                LimitSettingsControl.PilotNameSection.Visibility = Visibility.Collapsed;
                isVisible = false;
            }
        }
        /// <summary>
        /// Kaydedilmiş Kontrolcü Json Fomratlı Ayarlarını DeSerialize Yaparak Yükleyen Event
        /// </summary>
        private void UploadSettingsButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "JSON Files (*.json)|*.json";
            openFileDialog.Title = "Yüklemek için dosya seç";

            if (openFileDialog.ShowDialog() == true)
            {

                string filePath = openFileDialog.FileName;
                string jsonString = File.ReadAllText(filePath);

                if (CommonMethods.KUMANDA_TIPI.XBOX_KUMANDA == CommonMethods.WhichJoystick(CommonMethods.controller, CommonMethods.extremeJoystick))
                {
                    if (jsonString.Contains("XBox"))
                    {
                        FunctionsSettingsControl.listFunctionsButton.IsEnabled = false;
                        try
                        {
                            XBoxControllerClass = JsonSerializer.Deserialize<controlXBox>(jsonString);

                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                        FunctionsSettingsControl.functionsComboBox.SelectedIndex = CommonMethods.GetModeIndex(XBoxControllerClass.FunctionMode);
                        if (XBoxControllerClass.FunctionMode == CommonMethods.FunctionMode.NoMode)
                        {
                            CommonMethods.AddButtonsForFunctions(XBoxControllerClass, ExtremeControllerClass, CommonMethods.controller, CommonMethods.extremeJoystick);
                            FunctionsSettingsControl.listFunctionsButton.IsEnabled = true;
                        }
                        FunctionsSettingsControl.SetFunctionLists();
                        LimitSettingsControl.Set_Labels_For_XBox_Controller();
                        LimitSettingsControl.pilotError.Content = ($"Name: {XBoxControllerClass.PilotName} Başarıyla Yüklendi!");
                        LoadAllValues();
                       // FunctionsSettingsControl.ListFunctionsButton_Click(null, null);
                        AssignFunctionsButton_Click(null, null);
                    }
                    else
                    {
                        LimitSettingsControl.pilotError.Content = (" Extreme Controller Tipindeki  Ayarları xBox Controller Tipine Yükleyemezsiniz!");
                    }
                }
                else if (CommonMethods.KUMANDA_TIPI.EXTREME_KUMANDA == CommonMethods.WhichJoystick(CommonMethods.controller, CommonMethods.extremeJoystick))
                {
                    if (jsonString.Contains("Extreme"))
                    {
                        FunctionsSettingsControl.listFunctionsButton.IsEnabled = false;
                        try
                        {
                            ExtremeControllerClass = JsonSerializer.Deserialize<controlExtreme>(jsonString);

                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                        FunctionsSettingsControl.functionsComboBox.SelectedIndex = CommonMethods.GetModeIndex(ExtremeControllerClass.FunctionMode);
                        if (ExtremeControllerClass.FunctionMode == CommonMethods.FunctionMode.NoMode)
                        {
                            CommonMethods.AddButtonsForFunctions(XBoxControllerClass, ExtremeControllerClass, CommonMethods.controller, CommonMethods.extremeJoystick);
                            FunctionsSettingsControl.listFunctionsButton.IsEnabled = true;
                        }
                        FunctionsSettingsControl.SetFunctionLists();
                        LimitSettingsControl.Set_Labels_For_Extreme_Controller();
                        LimitSettingsControl.pilotError.Content = ($" Name: {ExtremeControllerClass.PilotName} Başarıyla Yüklendi!");
                        LoadAllValues();
                        //FunctionsSettingsControl.ListFunctionsButton_Click(null, null);
                        AssignFunctionsButton_Click(null,null);
                    }
                    else
                    {
                        LimitSettingsControl.pilotError.Content = (" xBox Controller Tipindeki  Ayarları Extreme Controller Tipine Yükleyemezsiniz!");
                    }
                }
            }
            else
            {
                LimitSettingsControl.pilotError.Content = ("Dosya yükleme iptal edildi.");
            }
        }
        /// <summary>
        /// Mode ComboBoxda Seçili Olan Ve Fonksiyon Ataması Yapılmış Olan Moda Göre İlgili Taba Yönlendiren Event
        /// </summary>
        public void GoModeButton_DoubleClick(object sender, RoutedEventArgs e)
        {

            if (CommonMethods.KUMANDA_TIPI.XBOX_KUMANDA == CommonMethods.WhichJoystick(CommonMethods.controller, CommonMethods.extremeJoystick))
            {
                if (XBoxControllerClass.FunctionList != null && XBoxControllerClass.FunctionMode != CommonMethods.FunctionMode.NoMode)
                {
                    Tabs.SelectedIndex = CommonMethods.GetModeIndex(XBoxControllerClass.FunctionMode) + 1;
                    showTab(tabs[CommonMethods.GetModeIndex(XBoxControllerClass.FunctionMode) + 1], CommonMethods.KUMANDA_TIPI.XBOX_KUMANDA);
                    this.WindowState = WindowState.Normal;
                    this.Width = 1300;
                    this.Height = 930;
                    this.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                    this.UpdateLayout();
                    this.ResizeMode = ResizeMode.NoResize;
                }
                else
                {
                    MessageBox.Show("Lütfen Önce Listeden Bir Mod Seçiniz!");
                }
            }
            else if (CommonMethods.KUMANDA_TIPI.EXTREME_KUMANDA == CommonMethods.WhichJoystick(CommonMethods.controller, CommonMethods.extremeJoystick))
            {
                if (ExtremeControllerClass.FunctionList != null && ExtremeControllerClass.FunctionMode != CommonMethods.FunctionMode.NoMode)
                {
                    Tabs.SelectedIndex = CommonMethods.GetModeIndex(ExtremeControllerClass.FunctionMode) + 1;
                    showTab(tabs[CommonMethods.GetModeIndex(ExtremeControllerClass.FunctionMode) + 1], CommonMethods.KUMANDA_TIPI.EXTREME_KUMANDA);
                }

                else
                {
                    MessageBox.Show("Lütfen Önce Listeden Bir Mod Seçiniz!");
                }
            }
        }
        /// <summary>
        /// Daha Sonra Kullanabilmek İçin Tüm Mevcut Tabları Tek Fonksiyonda Birleştiren Method
        /// </summary>
        public void AddAllTabs()
        {
            tabs.Add(settingsTab);
            tabs.Add(gimbalTab);
            tabs.Add(ihaTab);
            tabs.Add(allTab);
        }
        /// <summary>
        /// Parametre Aldığı TabItem a göre Diğer Tabların Visibility'sini Collepse Eden Method, Seçili Olan Kontrolcüye Göre Yönlendirilen Tabın BackGround Image Source ' unu Değiştirir.
        /// </summary>
        /// <param name="myItem">Gözükmesini İstediğimiz TabItem</param>
        public void showTab(TabItem myItem, CommonMethods.KUMANDA_TIPI whichJoystick)
        {
            if (myItem == settingsTab)
            {
                AllClear();
                tabs[CommonMethods.SettingsTabIndex].Visibility = Visibility.Visible;
                IsContinuousSecondAsync = false;
                IsContinuousMainAsync = true;
                StartReadingJoystickValues();
            }
            else if (myItem == gimbalTab)
            {
                Tabs.SelectedIndex = CommonMethods.GimbalTabIndex;
                if (CommonMethods.KUMANDA_TIPI.XBOX_KUMANDA == whichJoystick)
                {
                    gimbalPhoto.Source = new BitmapImage(new Uri("/Photos/xBox.png", UriKind.Relative));
                }
                else
                {
                    gimbalPhoto.Source = new BitmapImage(new Uri("/Photos/extremegif.gif", UriKind.Relative));
                }
                AllClear();
                tabs[CommonMethods.GimbalTabIndex].Visibility = Visibility.Visible;
                IsContinuousSecondAsync = true;
                IsContinuousMainAsync = false;
                ReadJoystickButtons();
            }
            else if (myItem == ihaTab)
            {
                Tabs.SelectedIndex = CommonMethods.IhaTabIndex;
                AllClear();
                if (CommonMethods.KUMANDA_TIPI.XBOX_KUMANDA == whichJoystick)
                {
                    ihaPhoto.Source = new BitmapImage(new Uri("/Photos/xBox.png", UriKind.Relative));
                }
                else
                {
                    ihaPhoto.Source = new BitmapImage(new Uri("/Photos/extremegif.gif", UriKind.Relative));
                }
                tabs[CommonMethods.IhaTabIndex].Visibility = Visibility.Visible;
                IsContinuousSecondAsync = true;
                IsContinuousMainAsync = false;
                ReadJoystickButtons();
            }
            else if (myItem == allTab)
            {
                Tabs.SelectedIndex = CommonMethods.AllTabIndex;
                AllClear();
                if (CommonMethods.KUMANDA_TIPI.XBOX_KUMANDA == whichJoystick)
                {
                    allPhoto.Source = new BitmapImage(new Uri("/Photos/xBox.png", UriKind.Relative));
                }
                else
                {
                    allPhoto.Source = new BitmapImage(new Uri("/Photos/extremegif.gif", UriKind.Relative));
                }
                tabs[CommonMethods.AllTabIndex].Visibility = Visibility.Visible;
                IsContinuousSecondAsync = true;
                IsContinuousMainAsync = false;
                ReadJoystickButtons();
            }

        }
        /// <summary>
        /// Farklı Taba Geçişlerde Tüm Tabları İnvisible Yapan Method.İlgili Method(ShowTab) Daha Sonrasında Mevcut Tabı Visible Yapar
        /// </summary>
        public void AllClear()
        {
            foreach (TabItem myItem in tabs) { myItem.Visibility = Visibility.Collapsed; }
        }
        /// <summary>
        /// Yönlendirilmiş Tabdan Geri Gelmek İçin Kullanılan Event
        /// </summary>
        private void GoSettings_Click(object sender, RoutedEventArgs e)
        {
            showTab(settingsTab, CommonMethods.WhichJoystick(CommonMethods.controller, CommonMethods.extremeJoystick));
            Tabs.SelectedIndex = 0;
            this.ResizeMode = ResizeMode.CanResize;
        }
        /// <summary>
        /// her SecondAsyncDelayTime Milisaniyede Bİr(Opsiyonel) Buton Değerlerini Bağlı Kontrolcüye Göre Okur.
        /// Ana Page Kapalıyken Gereksiz Method Çalışma Durumu Yaşanmasın Diye Ayrıca Yazılmıştır.
        /// </summary>
        private async void ReadJoystickButtons()
        {

            while (IsContinuousSecondAsync)
            {
                FunctionWorkingGimbal.Content = "";
                FunctionWorkingAll.Content = "";
                FunctionWorkingIha.Content = string.Empty;
                FunctionsSettingsControl.CheckButtonStates();
                await Task.Delay(SecondAsyncDelayTime);
            }

        }
        public void StartAnimation(Point point)
        {
            // Seçilen sekmeye göre doğru Canvas'ı belirle
            Canvas selectedCanvas = null;

            if (Tabs.SelectedIndex == 1)
            {
                selectedCanvas = AnimationCanvas;
            }
            else if (Tabs.SelectedIndex == 2)
            {
                selectedCanvas = AnimationCanvasIha;
            }
            else if (Tabs.SelectedIndex == 3)
            {
                selectedCanvas = AnimationCanvasAll;
            }

            if (selectedCanvas == null)
                return;

            Ellipse newEffectCircle = new Ellipse
            {
                Width = 30,
                Height = 30,
                Fill = Brushes.LimeGreen,
                Opacity = 1,
                Visibility = Visibility.Visible,
                RenderTransformOrigin = new Point(0.5, 0.5),
            };

            var scaleTransform = new ScaleTransform(2, 2);
            newEffectCircle.RenderTransform = scaleTransform;

            selectedCanvas.Children.Add(newEffectCircle);

            Canvas.SetLeft(newEffectCircle, point.X - newEffectCircle.Width / 2);
            Canvas.SetTop(newEffectCircle, point.Y - newEffectCircle.Height / 2);

            var scaleAnimation = new DoubleAnimation
            {
                From = 1,
                To = 2,
                Duration = TimeSpan.FromSeconds(0.1),
                AutoReverse = true
            };

            var opacityAnimation = new DoubleAnimation
            {
                From = 1,
                To = 0,
                Duration = TimeSpan.FromSeconds(0.2),
                AutoReverse = false
            };

            scaleTransform.BeginAnimation(ScaleTransform.ScaleXProperty, scaleAnimation);
            scaleTransform.BeginAnimation(ScaleTransform.ScaleYProperty, scaleAnimation);
            newEffectCircle.BeginAnimation(UIElement.OpacityProperty, opacityAnimation);
            opacityAnimation.Completed += (s, e) =>
            {
                selectedCanvas.Children.Remove(newEffectCircle);
            };
        }
        /// <summary>
        /// İndexlerine Göre ComboBoxlara Daha Önce Ayarlanmış Kontrolcü Classından Her Tanımlı Buton Karşılğında Bir Fonksiyon Olacak Şekilde Yüklemeleri Yapar. Bu Method Upload İşlemi Sırasında Kullanılır.
        /// </summary>
        private void LoadAllValues()
        {
            LimitSettingsControl.FillPageForControllers();
            if (CommonMethods.KUMANDA_TIPI.XBOX_KUMANDA == CommonMethods.WhichJoystick(CommonMethods.controller, CommonMethods.extremeJoystick))
            {
                int index = 0;
                foreach (FunctionRowController usercontrol in FunctionsSettingsControl.RowControlUserList)
                {
                    if (index < XBoxControllerClass.FunctionList.Count && XBoxControllerClass.FunctionList[index] != null && XBoxControllerClass.FunctionList[index].FunctionIndex != null)
                    {
                        if (XBoxControllerClass.FunctionList[index].VibrationState == CommonMethods.VibrationON)
                        {
                            usercontrol.CheckBox.IsChecked = true;
                        }
                        usercontrol.ComboBox.SelectedIndex = (int)XBoxControllerClass.FunctionList[index].FunctionIndex;
                    }
                    index++;
                }
            }
            else if (CommonMethods.KUMANDA_TIPI.EXTREME_KUMANDA == CommonMethods.WhichJoystick(CommonMethods.controller, CommonMethods.extremeJoystick))
            {
                int index = 0;
                foreach (ComboBox item in FunctionsSettingsControl.functionsListComboboxes)
                {
                    if (index < ExtremeControllerClass.FunctionList.Count && ExtremeControllerClass.FunctionList[index] != null && ExtremeControllerClass.FunctionList[index].FunctionIndex != null)
                    {
                        item.SelectedIndex = (int)ExtremeControllerClass.FunctionList[index].FunctionIndex;
                    }
                    index++;
                }
            }
        }
        private void ResetDataButton_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show(
                "Tüm Verileri Resetlemek istediğinizden emin misiniz?",
                "Onay",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning
            );

            if (result == MessageBoxResult.Yes)
            {
                if (CommonMethods.KUMANDA_TIPI.EXTREME_KUMANDA == CommonMethods.WhichJoystick(CommonMethods.controller, CommonMethods.extremeJoystick))
                {
                    ExtremeControllerClass = new controlExtreme();
                }
                else
                {
                    XBoxControllerClass = new controlXBox();
                }
                LoadAllValues();
                FunctionsSettingsControl.listFunctionsButton.IsEnabled = true;
                FunctionsSettingsControl.ResetFunctionLists();
            }
        }
        private void Quit_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show(
                "Çıkmak istediğinizden emin misiniz? Mevcut tüm değişiklikler silinecektir.",
                "Onay",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning
            );

            if (result == MessageBoxResult.Yes)
            {
                Application.Current.Shutdown();
            }
        }
    }
}
